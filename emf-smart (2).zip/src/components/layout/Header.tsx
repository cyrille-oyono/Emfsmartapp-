import React, { useState } from 'react';
import {
  Bell,
  Search,
  User as UserIcon,
  LogOut,
  Shield,
  Church,
  ExternalLink,
  Menu,
  ChevronDown,
  Share2,
  Globe,
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { Role } from '../../types';

import { ChurchLogo } from '../common/ChurchLogo';
import { NotificationBell } from '../notifications/NotificationBell';

interface HeaderProps {
  onToggleMobileMenu: () => void;
  onNavigate: (page: string) => void;
  currentPage: string;
}

export const Header: React.FC<HeaderProps> = ({
  onToggleMobileMenu,
  onNavigate,
  currentPage,
}) => {
  const { currentUser, logout, settings, loginAs } = useAuth();
  const [showRoleSwitcher, setShowRoleSwitcher] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);

  const rolesList: { role: Role; label: string; desc: string }[] = [
    { role: 'ADMIN', label: 'Admin (Cyrille Oyono)', desc: 'Accès complet et gestion CMS' },
    { role: 'PASTEUR', label: 'Pasteur (Samuel Ondoa)', desc: 'Direction pastorale & prédication' },
    { role: 'SECRÉTAIRE', label: 'Secrétaire (Chantal Mengue)', desc: 'Membres, familles, présences' },
    { role: 'TRÉSORIER', label: 'Trésorier (Emmanuel Mvondo)', desc: 'Comptabilité et reçus' },
    { role: 'RESPONSABLE_MINISTÈRE', label: 'Resp. Ministère (Paul Nnomo)', desc: 'Jeunesse (JEMF)' },
    { role: 'MEMBRE', label: 'Membre (Marie-Claire Bikoula)', desc: 'Fidèle & chantre' },
  ];

  return (
    <header className="sticky top-0 z-30 bg-[#0B2D54] text-white shadow-md border-b border-[#C99B2E]/30">
      <div className="flex items-center justify-between px-4 py-2 sm:px-6">
        {/* Left: Mobile Toggle & Brand */}
        <div className="flex items-center space-x-3">
          <button
            onClick={onToggleMobileMenu}
            className="md:hidden p-2 text-slate-200 hover:text-white hover:bg-[#123B6D] rounded-lg transition"
            aria-label="Menu"
          >
            <Menu className="w-5 h-5" />
          </button>

          <div
            onClick={() => {
              const isLeadership = currentUser?.role === 'ADMIN' || currentUser?.role === 'PASTEUR';
              onNavigate(isLeadership ? 'dashboard' : 'prayer-requests');
            }}
            className="cursor-pointer flex items-center space-x-2.5"
          >
            <ChurchLogo size="sm" />
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-extrabold text-base tracking-wider text-white">EMF SMART</span>
                <span className="text-[10px] uppercase tracking-widest px-1.5 py-0.5 rounded bg-[#C99B2E]/20 text-[#C99B2E] font-semibold border border-[#C99B2E]/40">
                  Sangmelima
                </span>
              </div>
              <p className="text-[11px] text-slate-300 hidden sm:block truncate max-w-xs">
                {settings.churchName}
              </p>
            </div>
          </div>
        </div>

        {/* Center: Quick Switch to Public Site / CMS / Web Publish */}
        <div className="hidden lg:flex items-center space-x-2 bg-[#123B6D]/80 px-2 py-1 rounded-lg border border-slate-700/50">
          <button
            onClick={() => onNavigate('public-home')}
            className={`px-3 py-1 text-xs font-medium rounded transition flex items-center space-x-1.5 cursor-pointer ${
              currentPage === 'public-home'
                ? 'bg-[#C99B2E] text-[#0B2D54] font-semibold'
                : 'text-slate-200 hover:text-white hover:bg-white/10'
            }`}
          >
            <ExternalLink className="w-3.5 h-3.5" />
            <span>Site Public</span>
          </button>
          {(currentUser?.role === 'ADMIN' || currentUser?.role === 'PASTEUR') && (
            <button
              onClick={() => onNavigate('web-publish')}
              className={`px-2.5 py-1 text-xs font-medium rounded transition flex items-center space-x-1.5 cursor-pointer ${
                currentPage === 'web-publish'
                  ? 'bg-emerald-600 text-white font-bold'
                  : 'text-emerald-300 hover:text-white hover:bg-emerald-600/30'
              }`}
              title="Publication Web Gratuite & Partage"
            >
              <Share2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>Publication Web</span>
            </button>
          )}
          {(currentUser?.role === 'ADMIN' || currentUser?.role === 'PASTEUR') && (
            <button
              onClick={() => onNavigate('dashboard')}
              className={`px-3 py-1 text-xs font-medium rounded transition cursor-pointer ${
                currentPage === 'dashboard'
                  ? 'bg-[#C99B2E] text-[#0B2D54] font-semibold'
                  : 'text-slate-200 hover:text-white hover:bg-white/10'
              }`}
            >
              <span>Tableau de bord</span>
            </button>
          )}
        </div>

        {/* Right: Role Switcher Pill + Notifications + Profile */}
        <div className="flex items-center space-x-2 sm:space-x-4">
          {/* Quick Demo Role Selector */}
          <div className="relative">
            <button
              onClick={() => setShowRoleSwitcher(!showRoleSwitcher)}
              className="flex items-center space-x-1.5 bg-[#123B6D] hover:bg-[#1a4a85] text-xs font-medium text-amber-300 border border-[#C99B2E]/40 px-2.5 py-1.5 rounded-lg transition shadow-sm"
              title="Changer rapidement de rôle de test (RBAC)"
            >
              <Shield className="w-3.5 h-3.5 text-[#C99B2E]" />
              <span className="hidden sm:inline font-bold">{currentUser?.role || 'INVITÉ'}</span>
              <ChevronDown className="w-3 h-3 text-slate-300" />
            </button>

            {showRoleSwitcher && (
              <div className="absolute right-0 mt-2 w-72 bg-white rounded-xl shadow-2xl border border-slate-200 text-slate-800 z-50 p-2">
                <div className="px-3 py-2 border-b border-slate-100">
                  <div className="text-xs font-bold uppercase text-slate-500 tracking-wider">
                    Simulateur de Rôle (RBAC)
                  </div>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    Permet de tester instantanément les permissions de chaque profil ecclésiastique.
                  </p>
                </div>
                <div className="py-1">
                  {rolesList.map((item) => (
                    <button
                      key={item.role}
                      onClick={() => {
                        loginAs(item.role);
                        if (item.role !== 'ADMIN' && item.role !== 'PASTEUR' && currentPage === 'dashboard') {
                          onNavigate('prayer-requests');
                        }
                        setShowRoleSwitcher(false);
                      }}
                      className={`w-full text-left px-3 py-2 rounded-lg text-xs flex flex-col transition ${
                        currentUser?.role === item.role
                          ? 'bg-blue-50 text-[#123B6D] font-bold border-l-4 border-[#123B6D]'
                          : 'hover:bg-slate-50 text-slate-700'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span>{item.label}</span>
                        {currentUser?.role === item.role && (
                          <span className="text-[10px] bg-[#123B6D] text-white px-1.5 py-0.2 rounded">
                            Actif
                          </span>
                        )}
                      </div>
                      <span className="text-[11px] text-slate-400 font-normal">{item.desc}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Notifications Bell */}
          <NotificationBell
            onNavigate={onNavigate}
            className="text-slate-300 hover:text-white hover:bg-[#123B6D]"
          />

          {/* User Profile */}
          <div className="relative">
            <button
              onClick={() => setShowUserMenu(!showUserMenu)}
              className="flex items-center space-x-2 p-1 rounded-lg hover:bg-[#123B6D] transition"
            >
              <div className="w-8 h-8 rounded-full bg-[#123B6D] border border-[#C99B2E] text-white flex items-center justify-center font-bold text-xs shadow-inner">
                {currentUser ? `${currentUser.firstName[0]}${currentUser.lastName[0]}` : <UserIcon className="w-4 h-4" />}
              </div>
              <div className="hidden md:block text-left text-xs leading-tight">
                <div className="font-semibold text-white">
                  {currentUser ? `${currentUser.firstName} ${currentUser.lastName}` : 'Invité'}
                </div>
                <div className="text-[10px] text-amber-300 font-medium">
                  {currentUser?.role || 'Non connecté'}
                </div>
              </div>
            </button>

            {showUserMenu && (
              <div className="absolute right-0 mt-2 w-56 bg-white rounded-xl shadow-2xl border border-slate-200 text-slate-800 z-50 p-2">
                <div className="px-3 py-2 border-b border-slate-100">
                  <p className="text-xs font-bold text-slate-900">
                    {currentUser ? `${currentUser.firstName} ${currentUser.lastName}` : 'Invité'}
                  </p>
                  <p className="text-[11px] text-slate-500 truncate">{currentUser?.email}</p>
                </div>
                <div className="py-1">
                  <button
                    onClick={() => {
                      onNavigate('settings');
                      setShowUserMenu(false);
                    }}
                    className="w-full text-left px-3 py-1.5 text-xs text-slate-700 hover:bg-slate-50 rounded flex items-center space-x-2"
                  >
                    <span>Mon profil & paramètres</span>
                  </button>
                  <button
                    onClick={() => {
                      onNavigate('audit');
                      setShowUserMenu(false);
                    }}
                    className="w-full text-left px-3 py-1.5 text-xs text-slate-700 hover:bg-slate-50 rounded flex items-center space-x-2"
                  >
                    <span>Journal d’audit</span>
                  </button>
                  <button
                    onClick={() => {
                      logout();
                      setShowUserMenu(false);
                    }}
                    className="w-full text-left px-3 py-1.5 text-xs text-red-600 hover:bg-red-50 rounded flex items-center space-x-2 mt-1 border-t border-slate-100"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    <span>Déconnexion</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
