import React, { useState, useEffect } from 'react';
import {
  Church,
  Calendar,
  Clock,
  MapPin,
  Phone,
  Mail,
  Heart,
  BookOpen,
  ArrowRight,
  ExternalLink,
  ChevronRight,
  Sun,
  Flame,
  Users,
  Shield,
  Download,
  Share2,
  X,
  Globe,
  Plus,
  Edit2,
  Sparkles,
  User as UserIcon,
  RefreshCw,
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { apiClient } from '../services/apiClient';
import { churchSyncService } from '../services/churchSyncService';
import {
  HomepageSection,
  Event,
  Testimonial,
  DailyBibleVerse,
  MediaItem,
  HomepageCarouselSlide,
  LatestServiceMedia,
  Announcement,
  WeeklyProgram,
} from '../types';
import { formatDateDouala } from '../utils/formatters';

import { ChurchLogo } from '../components/common/ChurchLogo';
import { HomeCarousel } from '../components/home/HomeCarousel';
import { ManageCarouselModal } from '../components/home/ManageCarouselModal';
import {
  ManageWeeklyProgramsModal,
  renderProgramIcon,
  getProgramColorClasses,
} from '../components/home/ManageWeeklyProgramsModal';
import { LatestServiceMediaSection } from '../components/media/LatestServiceMediaSection';
import { ChurchSocialsSection } from '../components/home/ChurchSocialsSection';
import { JoinCommunityModal } from '../components/home/JoinCommunityModal';
import { NotificationBell } from '../components/notifications/NotificationBell';
import { InteractiveHomeCalendar } from '../components/home/InteractiveHomeCalendar';
import { FooterChurchEditorModal } from '../components/home/FooterChurchEditorModal';

interface PublicHomePageProps {
  onGoToDashboard: () => void;
  onGoToCMS: () => void;
  onGoToPrayers?: () => void;
  onNavigateToPage?: (page: string) => void;
  onOpenPublish?: () => void;
}

export const PublicHomePage: React.FC<PublicHomePageProps> = ({
  onGoToDashboard,
  onGoToCMS,
  onGoToPrayers,
  onNavigateToPage,
  onOpenPublish,
}) => {
  const { settings, currentUser, refreshSettings } = useAuth();
  const [sections, setSections] = useState<HomepageSection[]>([]);
  const [events, setEvents] = useState<Event[]>([]);
  const [testimonials, setTestimonials] = useState<Testimonial[]>([]);
  const [todayVerse, setTodayVerse] = useState<DailyBibleVerse | undefined>();
  const [mediaItems, setMediaItems] = useState<MediaItem[]>([]);
  const [latestServiceMedia, setLatestServiceMedia] = useState<LatestServiceMedia | null>(null);
  const [carouselSlides, setCarouselSlides] = useState<HomepageCarouselSlide[]>([]);
  const [weeklyPrograms, setWeeklyPrograms] = useState<WeeklyProgram[]>([]);
  const [isManageCarouselOpen, setIsManageCarouselOpen] = useState(false);
  const [carouselModalCreateMode, setCarouselModalCreateMode] = useState(false);
  const [isManageProgramsOpen, setIsManageProgramsOpen] = useState(false);
  const [programsModalCreateMode, setProgramsModalCreateMode] = useState(false);
  const [isFooterEditorOpen, setIsFooterEditorOpen] = useState(false);
  const [selectedDayFilter, setSelectedDayFilter] = useState<string>('TOUS');
  const [eventsDisplayMode, setEventsDisplayMode] = useState<'calendar' | 'cards'>('calendar');
  const [isJoinCommunityOpen, setIsJoinCommunityOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [isSyncing, setIsSyncing] = useState(false);
  const [lastSyncedTime, setLastSyncedTime] = useState<string>(() =>
    new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit', second: '2-digit' })
  );

  const loadData = async () => {
    try {
      setLoading(true);
      const [secList, evts, tst, vrs, med, slides, lastMedia, progs] = await Promise.all([
        apiClient.getPublicHomepageSections(),
        apiClient.getEvents(),
        apiClient.getTestimonials(true), // only validated & published
        apiClient.getTodayVerse(),
        apiClient.getMediaItems(),
        apiClient.getCarouselSlides(),
        apiClient.getLatestServiceMedia(),
        apiClient.getWeeklyPrograms(),
      ]);
      setSections(secList);
      setEvents(evts);
      setTestimonials(tst);
      setTodayVerse(vrs);
      setMediaItems(med);
      setCarouselSlides(slides);
      setLatestServiceMedia(lastMedia);
      setWeeklyPrograms(progs);
      setLastSyncedTime(new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
    } catch (err) {
      console.error('Error loading public homepage:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleForceSync = async () => {
    try {
      setIsSyncing(true);
      await Promise.all([loadData(), refreshSettings()]);
      setLastSyncedTime(new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
    } catch (err) {
      console.error('Error during force sync:', err);
    } finally {
      setIsSyncing(false);
    }
  };

  useEffect(() => {
    loadData();

    // Subscribe to live church events across tabs and sockets
    const unsubscribe = churchSyncService.subscribe((event) => {
      if (event.type === 'church:settings_updated') {
        refreshSettings();
        setLastSyncedTime(new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
      } else if (event.type === 'church:agenda_updated') {
        Promise.all([apiClient.getWeeklyPrograms(), apiClient.getEvents()]).then(([progs, evts]) => {
          setWeeklyPrograms(progs);
          setEvents(evts);
          setLastSyncedTime(new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
        });
      } else if (event.type === 'church:cms_updated') {
        loadData();
      }
    });

    const handleFocus = () => {
      Promise.all([apiClient.getWeeklyPrograms(), apiClient.getEvents()]).then(([progs, evts]) => {
        setWeeklyPrograms(progs);
        setEvents(evts);
        setLastSyncedTime(new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
      });
    };
    window.addEventListener('focus', handleFocus);

    return () => {
      unsubscribe();
      window.removeEventListener('focus', handleFocus);
    };
  }, []);

  const getSection = (key: string) => sections.find((s) => s.key === key && s.isVisible);

  const heroSec = getSection('hero');
  const presentationSec = getSection('presentation');
  const servicesSec = getSection('services');
  const eventsSec = getSection('events');
  const verseSec = getSection('verse');
  const testimonialsSec = getSection('testimonials');
  const mediaSec = getSection('media');
  const ctaSec = getSection('cta');
  const footerSec = getSection('footer');

  const activeWeeklyPrograms = weeklyPrograms
    .filter((p) => p.isActive !== false)
    .sort((a, b) => (a.order || 0) - (b.order || 0));

  const upcomingEvents = [...events]
    .filter((e) => e.status !== 'ANNULÉ')
    .sort((a, b) => new Date(a.startDate).getTime() - new Date(b.startDate).getTime())
    .slice(0, 3);

  return (
    <div className="min-h-screen bg-[#F4F7FB] text-slate-800 flex flex-col font-sans selection:bg-[#C99B2E] selection:text-[#0B2D54]">
      {/* Top Banner Notice for Admin & Visitors */}
      <div className="bg-[#0B2D54] text-white text-xs py-2 px-4 border-b border-[#C99B2E]/30 flex items-center justify-between">
        <div className="flex items-center space-x-2 truncate">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span className="font-semibold text-amber-300 truncate">
            {settings.churchName} — Sangmelima (Sud, Cameroun)
          </span>
        </div>
        <div className="flex items-center space-x-3 flex-shrink-0">
          {(currentUser?.role === 'ADMIN' || currentUser?.role === 'PASTEUR') && onOpenPublish && (
            <button
              onClick={onOpenPublish}
              className="text-xs bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-2.5 py-0.5 rounded transition flex items-center space-x-1 cursor-pointer"
            >
              <Globe className="w-3 h-3 text-emerald-200" />
              <span>Publication Web Gratuite</span>
            </button>
          )}
          {(currentUser?.role === 'ADMIN' || currentUser?.role === 'PASTEUR') && (
            <button
              onClick={onGoToCMS}
              className="text-xs bg-[#C99B2E] text-[#0B2D54] font-bold px-2.5 py-0.5 rounded hover:bg-amber-400 transition cursor-pointer"
            >
              Éditer via le CMS
            </button>
          )}
          {(currentUser?.role === 'ADMIN' || currentUser?.role === 'PASTEUR') ? (
            <button
              onClick={onGoToDashboard}
              className="text-xs bg-[#123B6D] text-white font-medium px-2.5 py-0.5 rounded hover:bg-blue-800 transition cursor-pointer"
            >
              Tableau de Bord
            </button>
          ) : (
            <button
              onClick={onGoToPrayers || (() => onNavigateToPage?.('prayer-requests'))}
              className="text-xs bg-[#C99B2E] text-[#0B2D54] font-bold px-2.5 py-0.5 rounded hover:bg-amber-400 transition cursor-pointer"
            >
              Requêtes de Prière
            </button>
          )}
        </div>
      </div>

      {/* Public Header Navigation */}
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md shadow-sm border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <ChurchLogo size="md" />
            <div>
              <span className="font-black text-lg tracking-tight text-[#0B2D54]">
                EMF SANGMELIMA
              </span>
              <p className="text-[11px] text-slate-500 hidden sm:block">
                Église Missionnaire de la Foi
              </p>
            </div>
          </div>

          <nav className="hidden lg:flex items-center space-x-4 text-xs font-bold text-slate-600 uppercase tracking-wider">
            <a href="#about" className="hover:text-[#123B6D] transition">L’Église</a>
            <a href="#services" className="hover:text-[#123B6D] transition">Cultes</a>
            <button
              onClick={() => onNavigateToPage?.('media-gallery')}
              className="text-[#123B6D] hover:text-[#0B2D54] font-black transition flex items-center space-x-1 bg-amber-50 px-2.5 py-1 rounded-lg border border-amber-200 cursor-pointer"
            >
              <span>Vidéos & Photos</span>
              <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
            </button>
            <button
              onClick={() => onNavigateToPage?.('resources')}
              className="hover:text-[#123B6D] text-[#0B2D54] transition uppercase font-bold tracking-wider cursor-pointer flex items-center space-x-1"
            >
              <span>Ressources & Prières</span>
            </button>
            <button
              onClick={() => onNavigateToPage?.('finances')}
              className="hover:text-[#123B6D] text-emerald-700 transition uppercase font-black tracking-wider cursor-pointer flex items-center space-x-1"
            >
              <span>Dîmes & Offrandes</span>
            </button>
            <button
              onClick={() => onNavigateToPage?.('parakletos')}
              className="hover:text-[#123B6D] text-[#0B2D54] transition uppercase font-bold tracking-wider cursor-pointer"
            >
              <span>Institut Parakletos</span>
            </button>
            <button
              onClick={onGoToPrayers || onGoToDashboard}
              className="hover:text-[#123B6D] text-[#C99B2E] transition uppercase font-bold tracking-wider cursor-pointer"
            >
              Prières
            </button>
            <a href="#socials" className="hover:text-[#123B6D] transition">Réseaux</a>
          </nav>

          <div className="flex items-center space-x-2">
            <NotificationBell
              onNavigate={(page) => (onNavigateToPage ? onNavigateToPage(page) : onGoToDashboard())}
              className="text-[#0B2D54] hover:bg-slate-100 border border-slate-200"
            />
            {(currentUser?.role === 'ADMIN' || currentUser?.role === 'PASTEUR') && onOpenPublish && (
              <button
                onClick={onOpenPublish}
                className="px-3 py-2 rounded-xl bg-emerald-50 text-emerald-800 border border-emerald-300 text-xs font-bold hover:bg-emerald-100 transition shadow-xs flex items-center space-x-1.5 cursor-pointer"
                title="Partager ou publier le site web gratuitement"
              >
                <Share2 className="w-3.5 h-3.5 text-emerald-600" />
                <span className="hidden sm:inline">Partager le Site</span>
              </button>
            )}
            <button
              onClick={() => setIsJoinCommunityOpen(true)}
              className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-[#C99B2E] to-amber-500 hover:from-amber-500 hover:to-amber-600 text-[#0B2D54] font-black text-xs transition shadow-md flex items-center space-x-1.5 cursor-pointer"
            >
              <Heart className="w-3.5 h-3.5 fill-[#0B2D54]" />
              <span>Rejoindre la Communauté</span>
            </button>
            {(currentUser?.role === 'ADMIN' || currentUser?.role === 'PASTEUR') ? (
              <button
                onClick={onGoToDashboard}
                className="px-4 py-2 rounded-xl bg-[#0B2D54] text-white text-xs font-bold hover:bg-[#123B6D] transition shadow-md flex items-center space-x-1.5 cursor-pointer"
              >
                <span>Tableau de Bord</span>
                <ArrowRight className="w-3.5 h-3.5 text-[#C99B2E]" />
              </button>
            ) : (
              <button
                onClick={onGoToPrayers || (() => onNavigateToPage?.('prayer-requests'))}
                className="px-4 py-2 rounded-xl bg-[#0B2D54] text-white text-xs font-bold hover:bg-[#123B6D] transition shadow-md flex items-center space-x-1.5 cursor-pointer"
              >
                <span>Requêtes de Prière</span>
                <ArrowRight className="w-3.5 h-3.5 text-[#C99B2E]" />
              </button>
            )}
          </div>
        </div>
      </header>

      {/* Parish Alert Ticker Banner */}
      <div className="bg-[#0B2D54] text-white text-xs border-b border-[#C99B2E]/30 py-2 px-4 shadow-inner">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-3">
          <div className="flex items-center space-x-2 overflow-hidden truncate">
            <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse flex-shrink-0" />
            <span className="font-bold text-[#C99B2E] uppercase text-[10px] tracking-wider flex-shrink-0">
              Notification & Alertes :
            </span>
            <span className="truncate text-slate-200">
              Nouveau Message d’Enseignement, Communiqués de la Direction & Prochaines dates des cultes
            </span>
          </div>
          <button
            onClick={() => {
              if (onNavigateToPage) onNavigateToPage('media-gallery');
            }}
            className="flex-shrink-0 text-[11px] text-[#C99B2E] hover:underline font-bold flex items-center space-x-1 cursor-pointer"
          >
            <span>Voir les alertes</span>
            <ArrowRight className="w-3 h-3" />
          </button>
        </div>
      </div>

      {/* Image Carousel (Premier Showcase Visuel) */}
      <HomeCarousel
        slides={carouselSlides}
        onRefreshSlides={loadData}
        onNavigateToPage={onNavigateToPage}
        onOpenManageModal={(startInCreateMode = false) => {
          setCarouselModalCreateMode(startInCreateMode);
          setIsManageCarouselOpen(true);
        }}
      />

      {/* Presentation Section */}
      {presentationSec && (
        <section id="about" className="py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
            <div className="lg:col-span-7 space-y-5">
              <div className="text-xs font-black uppercase tracking-wider text-[#C99B2E]">
                Présentation Institutionnelle
              </div>
              <h2 className="text-2xl sm:text-4xl font-black text-[#0B2D54] tracking-tight">
                {presentationSec.title || 'Qui Sommes-Nous ?'}
              </h2>
              <p className="text-sm font-semibold text-slate-600">
                {presentationSec.subtitle}
              </p>
              <div className="text-sm text-slate-700 leading-relaxed space-y-3">
                <p>{presentationSec.content}</p>
              </div>

              {/* Statistics Counters */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-4 border-t border-slate-200">
                <div className="p-3 bg-white rounded-xl border border-slate-200 shadow-xs text-center">
                  <div className="text-2xl font-black text-[#0B2D54]">150+</div>
                  <div className="text-[11px] text-slate-500 font-medium">Familles Actives</div>
                </div>
                <div className="p-3 bg-white rounded-xl border border-slate-200 shadow-xs text-center">
                  <div className="text-2xl font-black text-[#C99B2E]">4 / sem.</div>
                  <div className="text-[11px] text-slate-500 font-medium">Cultes & Réunions</div>
                </div>
                <div className="p-3 bg-white rounded-xl border border-slate-200 shadow-xs text-center">
                  <div className="text-2xl font-black text-[#123B6D]">6</div>
                  <div className="text-[11px] text-slate-500 font-medium">Ministères d’Impact</div>
                </div>
                <div className="p-3 bg-white rounded-xl border border-slate-200 shadow-xs text-center">
                  <div className="text-2xl font-black text-emerald-700">15+</div>
                  <div className="text-[11px] text-slate-500 font-medium">Années à Sangmelima</div>
                </div>
              </div>
            </div>

            <div className="lg:col-span-5">
              <div className="rounded-3xl overflow-hidden shadow-2xl border-4 border-white bg-slate-200">
                <img
                  src={
                    presentationSec.imageUrl ||
                    'https://images.unsplash.com/photo-1511795409834-ef04bbd61622?auto=format&fit=crop&w=1000&q=80'
                  }
                  alt="Communauté EMF Sangmelima"
                  className="w-full h-80 sm:h-96 object-cover"
                />
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Services & Horaires des Cultes */}
      {servicesSec && (
        <section id="services" className="py-16 bg-white border-y border-slate-200 px-4 sm:px-6 lg:px-8">
          <div className="max-w-7xl mx-auto space-y-8">
            {/* Header & Admin Controls */}
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-2 border-b border-slate-100">
              <div className="space-y-2 max-w-2xl">
                <div className="inline-flex items-center space-x-2">
                  <span className="text-xs font-black uppercase tracking-wider text-[#C99B2E] bg-amber-50 px-3 py-1 rounded-full border border-amber-200">
                    Nos Rendez-vous Hebdomadaires
                  </span>
                  <span className="text-xs text-slate-400 font-bold">
                    • Temple d’Akon & Quartiers
                  </span>
                </div>
                <h2 className="text-2xl sm:text-4xl font-black text-[#0B2D54] tracking-tight">
                  {servicesSec.title || 'Cultes & Réunions de Foi'}
                </h2>
                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                  {servicesSec.subtitle ||
                    'Rejoignez notre assemblée vivante pour adorer le Seigneur, grandir dans Sa Parole et expérimenter la puissance du Saint-Esprit.'}
                </p>
              </div>

              {/* Admin Floating / Inline Quick Controls */}
              {(currentUser?.role === 'ADMIN' || currentUser?.role === 'PASTEUR') && (
                <div className="flex flex-wrap items-center gap-2 p-2.5 bg-gradient-to-r from-amber-50 to-blue-50/70 rounded-2xl border border-[#C99B2E]/40 shrink-0">
                  <div className="text-[10px] font-black uppercase tracking-wider text-[#0B2D54] px-2 py-1 bg-white rounded-lg border border-slate-200 flex items-center space-x-1">
                    <Sparkles className="w-3 h-3 text-[#C99B2E]" />
                    <span>Admin Cultes</span>
                  </div>
                  <button
                    onClick={() => {
                      setProgramsModalCreateMode(true);
                      setIsManageProgramsOpen(true);
                    }}
                    className="flex items-center space-x-1.5 px-3 py-1.5 bg-[#0B2D54] hover:bg-[#123B6D] text-white text-xs font-black rounded-xl shadow-xs transition cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5 text-[#C99B2E]" />
                    <span>+ Ajouter un Programme</span>
                  </button>
                  <button
                    onClick={() => {
                      setProgramsModalCreateMode(false);
                      setIsManageProgramsOpen(true);
                    }}
                    className="flex items-center space-x-1.5 px-3 py-1.5 bg-white hover:bg-slate-50 text-[#0B2D54] text-xs font-bold rounded-xl border border-slate-300 shadow-xs transition cursor-pointer"
                  >
                    <Calendar className="w-3.5 h-3.5 text-[#C99B2E]" />
                    <span>Gérer les Programmes ({weeklyPrograms.length})</span>
                  </button>
                </div>
              )}
            </div>

            {/* Day Filter Pills */}
            <div className="flex flex-wrap items-center gap-1.5 overflow-x-auto pb-1">
              <button
                onClick={() => setSelectedDayFilter('TOUS')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center space-x-1.5 cursor-pointer ${
                  selectedDayFilter === 'TOUS'
                    ? 'bg-[#0B2D54] text-white shadow-xs'
                    : 'bg-[#F4F7FB] text-slate-600 hover:bg-slate-200 border border-slate-200'
                }`}
              >
                <span>Tous les programmes</span>
                <span className="text-[10px] opacity-80 bg-white/20 px-1.5 py-0.2 rounded-full">
                  {currentUser?.role === 'ADMIN' || currentUser?.role === 'PASTEUR'
                    ? weeklyPrograms.length
                    : weeklyPrograms.filter((p) => p.isActive).length}
                </span>
              </button>

              {['Dimanche', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi'].map((day) => {
                const count = weeklyPrograms.filter(
                  (p) =>
                    p.dayOfWeek === day &&
                    (currentUser?.role === 'ADMIN' || currentUser?.role === 'PASTEUR' || p.isActive)
                ).length;
                if (count === 0 && selectedDayFilter !== day) return null;
                return (
                  <button
                    key={day}
                    onClick={() => setSelectedDayFilter(day)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center space-x-1.5 cursor-pointer ${
                      selectedDayFilter === day
                        ? 'bg-[#C99B2E] text-[#0B2D54] shadow-xs'
                        : 'bg-[#F4F7FB] text-slate-600 hover:bg-slate-200 border border-slate-200'
                    }`}
                  >
                    <span>{day}</span>
                    <span className="text-[10px] font-bold bg-white/40 px-1.5 py-0.2 rounded-full">
                      {count}
                    </span>
                  </button>
                );
              })}
            </div>

            {/* Programs Cards Grid */}
            {(() => {
              const displayable = weeklyPrograms.filter((prog) => {
                const isRoleAdmin =
                  currentUser?.role === 'ADMIN' || currentUser?.role === 'PASTEUR';
                if (!isRoleAdmin && !prog.isActive) return false;
                if (selectedDayFilter === 'TOUS') return true;
                return prog.dayOfWeek === selectedDayFilter || prog.dayOfWeek === 'Tous les jours';
              });

              if (displayable.length === 0) {
                return (
                  <div className="text-center py-12 px-4 rounded-3xl bg-[#F4F7FB] border-2 border-dashed border-slate-200 space-y-3">
                    <Calendar className="w-10 h-10 text-slate-300 mx-auto" />
                    <p className="text-sm font-bold text-slate-700">
                      Aucun programme trouvé pour ce filtre ({selectedDayFilter})
                    </p>
                    <p className="text-xs text-slate-500 max-w-sm mx-auto">
                      Consultez les autres jours ou réinitialisez le filtre pour découvrir tous les rendez-vous de l’assemblée.
                    </p>
                    {(currentUser?.role === 'ADMIN' || currentUser?.role === 'PASTEUR') && (
                      <button
                        onClick={() => {
                          setProgramsModalCreateMode(true);
                          setIsManageProgramsOpen(true);
                        }}
                        className="px-4 py-2 bg-[#0B2D54] text-white text-xs font-bold rounded-xl shadow hover:bg-[#123B6D] transition"
                      >
                        + Ajouter un programme pour {selectedDayFilter}
                      </button>
                    )}
                  </div>
                );
              }

              return (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                  {displayable.map((prog) => {
                    const colors = getProgramColorClasses(prog.colorTheme);
                    const isAdmin =
                      currentUser?.role === 'ADMIN' || currentUser?.role === 'PASTEUR';

                    return (
                      <div
                        key={prog.id}
                        className={`p-6 rounded-3xl bg-[#F4F7FB] border transition-all duration-200 shadow-xs group flex flex-col justify-between relative ${
                          prog.isActive
                            ? `border-slate-200 ${colors.borderHover} hover:shadow-md hover:-translate-y-1`
                            : 'border-dashed border-amber-300 opacity-75 bg-amber-50/20'
                        }`}
                      >
                        {/* Admin Quick Edit Button */}
                        {isAdmin && (
                          <button
                            onClick={() => {
                              setProgramsModalCreateMode(false);
                              setIsManageProgramsOpen(true);
                            }}
                            className="absolute top-4 right-4 p-1.5 rounded-lg bg-white/90 hover:bg-[#0B2D54] hover:text-white text-slate-400 border border-slate-200 shadow-2xs opacity-0 group-hover:opacity-100 transition cursor-pointer"
                            title="Modifier ce programme"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                        )}

                        <div>
                          {/* Top Row: Icon + Day Badge */}
                          <div className="flex items-center justify-between mb-4">
                            <div
                              className={`w-12 h-12 rounded-2xl flex items-center justify-center font-bold shadow-xs group-hover:scale-105 transition ${colors.iconBg}`}
                            >
                              {renderProgramIcon(prog.iconName, 'w-6 h-6')}
                            </div>

                            <div className="flex flex-col items-end space-y-1">
                              <span
                                className={`text-[10px] font-black uppercase tracking-wider px-2.5 py-0.5 rounded-full border shadow-2xs ${colors.badgeBg}`}
                              >
                                {prog.dayOfWeek}
                              </span>
                              {!prog.isActive && (
                                <span className="text-[9px] font-black text-rose-600 bg-rose-50 px-1.5 py-0.2 rounded border border-rose-200">
                                  Masqué
                                </span>
                              )}
                            </div>
                          </div>

                          {/* Title */}
                          <h3 className="text-base font-black text-[#0B2D54] mb-1.5 leading-snug group-hover:text-[#123B6D]">
                            {prog.title}
                          </h3>

                          {/* Time */}
                          <div
                            className={`text-xs font-black mb-3 flex items-center space-x-1.5 ${colors.timeText}`}
                          >
                            <Clock className="w-3.5 h-3.5 shrink-0" />
                            <span>
                              {prog.dayOfWeek} : {prog.time}
                            </span>
                          </div>

                          {/* Description */}
                          <p className="text-xs text-slate-600 leading-relaxed mb-4">
                            {prog.description}
                          </p>
                        </div>

                        {/* Card Footer: Location, Minister, Audience */}
                        <div className="pt-3 border-t border-slate-200/80 space-y-2 text-[11px] text-slate-500 font-medium">
                          <div className="flex items-center justify-between gap-2">
                            <span className="flex items-center space-x-1 truncate">
                              <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                              <span className="truncate">{prog.location}</span>
                            </span>

                            {prog.targetAudience && (
                              <span className="text-[10px] font-bold text-slate-600 bg-white px-2 py-0.5 rounded-md border border-slate-200 shrink-0">
                                {prog.targetAudience}
                              </span>
                            )}
                          </div>

                          {prog.leaderOrMinister && (
                            <div className="flex items-center space-x-1 text-[11px] text-[#0B2D54] font-bold truncate">
                              <UserIcon className="w-3 h-3 text-[#C99B2E] shrink-0" />
                              <span className="truncate">{prog.leaderOrMinister}</span>
                            </div>
                          )}

                          {prog.notes && (
                            <div className="text-[10px] italic text-slate-400 line-clamp-1 pt-0.5">
                              Note : {prog.notes}
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              );
            })()}
          </div>
        </section>
      )}

      {/* Médiathèque des Photos et Vidéos du Dernier Culte */}
      {latestServiceMedia && (
        <LatestServiceMediaSection
          data={latestServiceMedia}
          onRefresh={loadData}
        />
      )}

      {/* Daily Bible Verse Spotlight (Africa/Douala Live) */}
      {verseSec && todayVerse && (
        <section id="verse" className="py-16 px-4 sm:px-6 lg:px-8 max-w-5xl mx-auto">
          <div className="bg-gradient-to-br from-[#0B2D54] to-[#123B6D] text-white rounded-3xl p-8 sm:p-12 shadow-2xl border-2 border-[#C99B2E] relative overflow-hidden">
            <div className="relative space-y-4 text-center">
              <span className="text-xs font-black uppercase tracking-widest text-[#C99B2E] bg-white/10 px-3 py-1 rounded-full border border-white/20">
                Verset du Jour • Heure de Sangmelima ({formatDateDouala(todayVerse.date)})
              </span>

              <div className="font-serif italic text-xl sm:text-3xl text-amber-100 font-medium max-w-3xl mx-auto leading-relaxed pt-2">
                « {todayVerse.text} »
              </div>

              <div className="text-sm font-bold text-[#C99B2E] tracking-wider">
                — {todayVerse.reference} ({todayVerse.translation})
              </div>

              {todayVerse.meditation && (
                <div className="text-xs text-slate-200 max-w-2xl mx-auto pt-4 border-t border-white/10 leading-relaxed">
                  <strong className="text-white">Méditation pastorale : </strong>
                  {todayVerse.meditation}
                </div>
              )}

              {todayVerse.prayer && (
                <div className="text-xs italic text-amber-200/90 max-w-2xl mx-auto pt-2">
                  <strong className="text-amber-300">Prière : </strong>
                  « {todayVerse.prayer} »
                </div>
              )}
            </div>
          </div>
        </section>
      )}

      {/* Upcoming Events & Interactive Calendar Section */}
      {eventsSec && (
        <section id="events" className="py-16 bg-[#F4F7FB] border-y border-slate-200 px-4 sm:px-6 lg:px-8">
          <div className="max-w-7xl mx-auto space-y-8">
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
              <div>
                <div className="text-xs font-black uppercase tracking-wider text-[#C99B2E] flex items-center space-x-1.5 mb-1">
                  <Calendar className="w-3.5 h-3.5" />
                  <span>Agenda Spirituel • Sangmelima</span>
                </div>
                <h2 className="text-2xl sm:text-4xl font-black text-[#0B2D54]">
                  {eventsSec.title || 'Agenda & Calendrier Spirituel'}
                </h2>
                <p className="text-xs sm:text-sm text-slate-600 mt-1 max-w-2xl leading-relaxed">
                  {eventsSec.subtitle ||
                    'Visualisez tous les cultes, réunions de prière et conférences de la semaine et du mois en un coup d’œil.'}
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2.5">
                {/* Switcher: Calendrier interactif vs Cartes à la une */}
                <div className="inline-flex bg-white p-1 rounded-2xl border border-slate-200 shadow-2xs">
                  <button
                    type="button"
                    onClick={() => setEventsDisplayMode('calendar')}
                    className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition flex items-center space-x-1.5 cursor-pointer ${
                      eventsDisplayMode === 'calendar'
                        ? 'bg-[#0B2D54] text-white shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    <Calendar className="w-3.5 h-3.5" />
                    <span>Calendrier Interactif</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setEventsDisplayMode('cards')}
                    className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition flex items-center space-x-1.5 cursor-pointer ${
                      eventsDisplayMode === 'cards'
                        ? 'bg-[#0B2D54] text-white shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    <span>Cartes à la Une</span>
                    {events.length > 0 && (
                      <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-amber-100 text-[#0B2D54] font-black">
                        {events.length}
                      </span>
                    )}
                  </button>
                </div>

                <button
                  onClick={onGoToDashboard}
                  className="text-xs font-bold text-[#123B6D] hover:underline flex items-center space-x-1 py-1.5 px-2 cursor-pointer"
                >
                  <span>Espace Membre</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Display Mode: Interactive Calendar */}
            {eventsDisplayMode === 'calendar' ? (
              <InteractiveHomeCalendar
                events={events}
                weeklyPrograms={weeklyPrograms}
                currentUser={currentUser}
                onRefresh={loadData}
                onOpenWeeklyPrograms={() => {
                  setProgramsModalCreateMode(false);
                  setIsManageProgramsOpen(true);
                }}
              />
            ) : (
              /* Display Mode: 3 Spotlight Cards */
              <div className="space-y-6">
                {events.length === 0 ? (
                  <div className="p-8 text-center bg-white rounded-3xl border border-slate-200 text-xs text-slate-500">
                    Aucun événement spécial pour l’instant. Basculez sur le « Calendrier Interactif » pour voir tous les cultes hebdomadaires.
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {events.slice(0, 3).map((evt) => (
                      <div
                        key={evt.id}
                        className="bg-white rounded-3xl overflow-hidden border border-slate-200 shadow-xs hover:shadow-md transition flex flex-col group"
                      >
                        <div className="h-48 bg-slate-200 relative overflow-hidden">
                          <img
                            src={
                              evt.bannerUrl ||
                              'https://images.unsplash.com/photo-1519791883288-dc8bd696e667?auto=format&fit=crop&w=800&q=80'
                            }
                            alt={evt.title}
                            className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                          />
                          <span className="absolute top-3 left-3 bg-[#0B2D54]/90 backdrop-blur-xs text-[#C99B2E] text-[10px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full border border-[#C99B2E]/30">
                            {evt.type}
                          </span>
                        </div>

                        <div className="p-6 flex-1 flex flex-col justify-between space-y-4">
                          <div>
                            <div className="text-xs text-[#C99B2E] font-black mb-1.5 flex items-center space-x-1.5">
                              <Calendar className="w-3.5 h-3.5" />
                              <span>{formatDateDouala(evt.startDate)}</span>
                            </div>
                            <h3 className="text-base font-black text-[#0B2D54] line-clamp-2 leading-snug group-hover:text-[#123B6D]">
                              {evt.title}
                            </h3>
                            <p className="text-xs text-slate-600 mt-2 line-clamp-3 leading-relaxed">
                              {evt.description}
                            </p>
                          </div>

                          <div className="pt-3 border-t border-slate-100 text-xs text-slate-500 flex items-center justify-between">
                            <span className="flex items-center space-x-1.5 truncate">
                              <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                              <span className="truncate">{evt.location}</span>
                            </span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        </section>
      )}

      {/* Validated Testimonials Section */}
      {testimonialsSec && testimonials.length > 0 && (
        <section id="testimonials" className="py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
          <div className="text-center max-w-3xl mx-auto mb-12 space-y-2">
            <div className="text-xs font-black uppercase tracking-wider text-[#C99B2E]">
              Actions de Grâce & Témoignages
            </div>
            <h2 className="text-2xl sm:text-4xl font-black text-[#0B2D54]">
              {testimonialsSec.title || 'Ce que le Seigneur a Fait'}
            </h2>
            <p className="text-xs sm:text-sm text-slate-600">{testimonialsSec.subtitle}</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {testimonials.slice(0, 2).map((tst) => (
              <div
                key={tst.id}
                className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm flex flex-col justify-between"
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-amber-100 text-[#0B2D54]">
                      {tst.category}
                    </span>
                    <span className="text-[11px] text-slate-400">
                      {formatDateDouala(tst.createdAt)}
                    </span>
                  </div>
                  <h3 className="text-base font-bold text-[#0B2D54]">{tst.title}</h3>
                  <p className="text-xs text-slate-700 leading-relaxed italic">
                    « {tst.content} »
                  </p>
                </div>

                <div className="pt-4 mt-4 border-t border-slate-100 flex items-center justify-between text-xs">
                  <span className="font-bold text-[#123B6D]">
                    {tst.isIdentityVisible ? tst.authorName : 'Une âme bénie (Anonyme)'}
                  </span>
                  <span className="text-[11px] text-emerald-600 font-semibold">
                    ✓ Témoignage certifié
                  </span>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Call to Action Section */}
      {ctaSec && (
        <section
          id="cta"
          className="bg-gradient-to-r from-[#0B2D54] via-[#123B6D] to-[#0B2D54] text-white py-16 px-4 sm:px-6 lg:px-8 text-center"
        >
          <div className="max-w-4xl mx-auto space-y-6">
            <h2 className="text-2xl sm:text-4xl font-black tracking-tight">
              {ctaSec.title || 'Vous cherchez une famille spirituelle à Sangmelima ?'}
            </h2>
            <p className="text-sm sm:text-base text-slate-200 max-w-2xl mx-auto leading-relaxed">
              {ctaSec.subtitle || 'Les portes de l’Église Missionnaire de la Foi vous sont grandes ouvertes.'}
            </p>
            <div className="flex flex-wrap justify-center gap-3 pt-2">
              <button
                onClick={() => setIsJoinCommunityOpen(true)}
                className="px-6 py-3 rounded-xl bg-[#C99B2E] text-[#0B2D54] text-xs font-black hover:bg-amber-400 transition shadow-lg cursor-pointer flex items-center space-x-2"
              >
                <Heart className="w-4 h-4 fill-[#0B2D54]" />
                <span>{ctaSec.primaryButtonText || 'Rejoindre la communauté'}</span>
              </button>
              <a
                href={`tel:${settings.phone}`}
                className="px-6 py-3 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold transition border border-white/20 flex items-center space-x-1.5"
              >
                <Phone className="w-3.5 h-3.5" />
                <span>{ctaSec.secondaryButtonText || 'Parler à un pasteur'}</span>
              </a>
            </div>
          </div>
        </section>
      )}

      {/* Liens Sociaux & Communauté Numérique de l'Église */}
      <ChurchSocialsSection settings={settings} />

      {/* Footer Paroissial Intelligent & Synchronisé */}
      <footer id="contact" className="bg-[#071d37] text-slate-300 pt-12 pb-8 px-4 sm:px-6 lg:px-8 border-t border-[#123B6D] relative">
        {/* Barre de Statut de Synchronisation en Direct & Contrôle Admin */}
        <div className="max-w-7xl mx-auto mb-8 p-3.5 sm:p-4 rounded-2xl bg-[#092547] border border-[#18457e] flex flex-col md:flex-row items-start md:items-center justify-between gap-3 shadow-md">
          <div className="flex items-center space-x-3">
            <div className="relative flex items-center justify-center shrink-0">
              <span className="w-3 h-3 rounded-full bg-emerald-400 animate-ping absolute" />
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 relative" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="text-xs font-black text-white tracking-wide">
                  Pied de page synchronisé en direct avec l'administration & l'agenda
                </span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-950/80 text-emerald-300 border border-emerald-500/30">
                  Temps Réel Actif
                </span>
              </div>
              <p className="text-[11px] text-slate-400">
                Les coordonnées officielles, cultes réguliers ({activeWeeklyPrograms.length}) et l'agenda des rassemblements ({events.length}) sont actualisés automatiquement dès modification par l'admin.
                {lastSyncedTime && (
                  <span className="ml-1 text-amber-300/90 font-medium">
                    • Dernière synchronisation à {lastSyncedTime}
                  </span>
                )}
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2 self-end md:self-auto shrink-0">
            <button
              onClick={() => handleForceSync()}
              disabled={isSyncing}
              className="text-xs px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-slate-200 hover:text-white font-bold transition flex items-center space-x-1.5 border border-white/15 cursor-pointer disabled:opacity-50"
              title="Forcer la réactualisation des données"
            >
              <RefreshCw className={`w-3.5 h-3.5 text-[#C99B2E] ${isSyncing ? 'animate-spin' : ''}`} />
              <span>{isSyncing ? 'Actualisation...' : 'Actualiser'}</span>
            </button>

            {(currentUser?.role === 'ADMIN' || currentUser?.role === 'PASTEUR') && (
              <button
                onClick={() => setIsFooterEditorOpen(true)}
                className="text-xs px-3.5 py-1.5 rounded-xl bg-[#C99B2E] hover:bg-amber-400 text-[#0B2D54] font-black transition flex items-center space-x-1.5 shadow-sm cursor-pointer"
                title="Modifier les coordonnées et l'agenda du pied de page"
              >
                <Edit2 className="w-3.5 h-3.5 text-[#0B2D54]" />
                <span>Modifier Coordonnées & Agenda</span>
              </button>
            )}
          </div>
        </div>

        {/* Grille Principale à 4 Colonnes */}
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-10 text-xs">
          {/* Colonne 1 : Identité & Mission Spirituelle */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2.5">
              <ChurchLogo size="sm" />
              <div>
                <span className="font-black text-base text-white block leading-tight">EMF SMART</span>
                <span className="text-[10px] text-amber-400 font-bold uppercase tracking-wider">
                  Sangmelima • Sud Cameroun
                </span>
              </div>
            </div>
            <p className="text-slate-300 text-xs leading-relaxed">
              {settings.slogan ||
                'Une église vivante au cœur du Sud, enracinée dans la Parole et tournée vers les nations.'}
            </p>
            <div className="space-y-1 text-[11px] text-slate-400">
              <p className="flex items-start space-x-1.5">
                <MapPin className="w-3.5 h-3.5 text-[#C99B2E] shrink-0 mt-0.5" />
                <span>{settings.address || 'Quartier Akon, Route Principale, Sangmelima'}</span>
              </p>
              <p className="text-[10px] text-slate-500 pl-5">
                Département du Dja-et-Lobo, Région du Sud, République du Cameroun.
              </p>
            </div>

            {/* Réseaux Sociaux Officiels */}
            <div className="pt-2">
              <span className="font-bold uppercase tracking-wider text-[#C99B2E] text-[10px] block mb-2">
                Réseaux Sociaux Officiels :
              </span>
              <div className="flex items-center space-x-2">
                {settings.socials.facebook && (
                  <a
                    href={settings.socials.facebook}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-8 h-8 rounded-full bg-slate-800 hover:bg-[#1877F2] text-slate-300 hover:text-white transition flex items-center justify-center border border-slate-700"
                    title="Facebook EMF Sangmelima"
                  >
                    <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                      <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
                    </svg>
                  </a>
                )}

                {settings.socials.youtube && (
                  <a
                    href={settings.socials.youtube}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-8 h-8 rounded-full bg-slate-800 hover:bg-[#FF0000] text-slate-300 hover:text-white transition flex items-center justify-center border border-slate-700"
                    title="Chaîne YouTube EMF"
                  >
                    <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                      <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z" />
                    </svg>
                  </a>
                )}

                {settings.socials.whatsapp && (
                  <a
                    href={
                      settings.socials.whatsapp.startsWith('http')
                        ? settings.socials.whatsapp
                        : `https://wa.me/${settings.socials.whatsapp.replace(/\D/g, '')}`
                    }
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-8 h-8 rounded-full bg-slate-800 hover:bg-[#25D366] text-slate-300 hover:text-white transition flex items-center justify-center border border-slate-700"
                    title="WhatsApp EMF Sangmelima"
                  >
                    <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                      <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.414-.003 6.557-5.338 11.892-11.893 11.892-1.99-.001-3.951-.5-5.688-1.448l-6.305 1.654zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884-.001 2.225.651 3.891 1.746 5.634l-.999 3.648 3.742-.981zm11.387-5.464c-.074-.124-.272-.198-.57-.347-.297-.149-1.758-.868-2.031-.967-.272-.099-.47-.149-.669.149-.198.297-.768.967-.941 1.165-.173.198-.347.223-.644.074-.297-.149-1.255-.462-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.297-.347.446-.521.151-.172.2-.296.3-.495.099-.198.05-.372-.025-.521-.075-.148-.669-1.611-.916-2.206-.242-.579-.487-.501-.669-.51l-.57-.01c-.198 0-.52.074-.792.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.095 3.2 5.076 4.487.709.306 1.263.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.695.248-1.29.173-1.414z" />
                    </svg>
                  </a>
                )}

                {settings.socials.instagram && (
                  <a
                    href={settings.socials.instagram}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-8 h-8 rounded-full bg-slate-800 hover:bg-[#E1306C] text-slate-300 hover:text-white transition flex items-center justify-center border border-slate-700"
                    title="Instagram EMF Sangmelima"
                  >
                    <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                      <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" />
                    </svg>
                  </a>
                )}

                {settings.socials.telegram && (
                  <a
                    href={settings.socials.telegram}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-8 h-8 rounded-full bg-slate-800 hover:bg-[#0088CC] text-slate-300 hover:text-white transition flex items-center justify-center border border-slate-700"
                    title="Telegram EMF"
                  >
                    <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                      <path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm5.894 8.221l-1.97 9.28c-.145.658-.537.818-1.084.508l-3-2.21-1.446 1.394c-.14.18-.357.295-.6.295-.002 0-.003 0-.005 0l.213-3.054 5.56-5.022c.24-.213-.054-.334-.373-.121l-6.869 4.326-2.96-.924c-.643-.204-.657-.643.136-.953l11.57-4.458c.538-.196 1.006.128.832.939z" />
                    </svg>
                  </a>
                )}
              </div>
            </div>
          </div>

          {/* Colonne 2 : Horaires des Cultes & Rendez-vous Hebdomadaires (Dynamique Synchronisé) */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-bold uppercase tracking-wider text-[#C99B2E] text-[11px] flex items-center space-x-1.5">
                <Clock className="w-3.5 h-3.5 text-[#C99B2E]" />
                <span>Horaires des Cultes</span>
              </span>
              <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-md bg-amber-400/20 text-amber-300 border border-amber-400/30">
                {activeWeeklyPrograms.length} cultes
              </span>
            </div>

            {activeWeeklyPrograms.length > 0 ? (
              <ul className="space-y-2 text-slate-300">
                {activeWeeklyPrograms.map((prog) => (
                  <li
                    key={prog.id}
                    className="p-2 rounded-xl bg-slate-800/70 border border-slate-700/60 hover:border-[#C99B2E]/50 transition group"
                  >
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="font-black text-amber-300 uppercase tracking-wide">
                        {prog.dayOfWeek}
                      </span>
                      <span className="text-[10px] text-slate-400 font-bold flex items-center space-x-1">
                        <Clock className="w-2.5 h-2.5 text-[#C99B2E]" />
                        <span>{prog.time}</span>
                      </span>
                    </div>
                    <p className="font-bold text-white text-xs mt-0.5 group-hover:text-amber-200 transition">
                      {prog.title}
                    </p>
                    {prog.location && (
                      <p className="text-[10px] text-slate-400 flex items-center space-x-1 mt-0.5">
                        <MapPin className="w-2.5 h-2.5 text-slate-500" />
                        <span className="truncate">{prog.location}</span>
                      </p>
                    )}
                  </li>
                ))}
              </ul>
            ) : (
              <div className="p-3 rounded-xl bg-slate-800/50 border border-slate-700 text-slate-400 text-xs">
                Aucun culte régulier configuré pour le moment.
              </div>
            )}

            {(currentUser?.role === 'ADMIN' || currentUser?.role === 'PASTEUR') && (
              <button
                onClick={() => {
                  setProgramsModalCreateMode(false);
                  setIsManageProgramsOpen(true);
                }}
                className="text-[11px] text-[#C99B2E] hover:text-amber-300 font-bold transition flex items-center space-x-1 pt-1 cursor-pointer"
              >
                <span>+ Gérer les programmes hebdomadaires</span>
              </button>
            )}
          </div>

          {/* Colonne 3 : Agenda & Prochains Événements (Dynamique Synchronisé) */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-bold uppercase tracking-wider text-[#C99B2E] text-[11px] flex items-center space-x-1.5">
                <Calendar className="w-3.5 h-3.5 text-[#C99B2E]" />
                <span>Agenda Paroissial</span>
              </span>
              <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-md bg-blue-400/20 text-blue-300 border border-blue-400/30">
                {events.length} événements
              </span>
            </div>

            {upcomingEvents.length > 0 ? (
              <ul className="space-y-2 text-slate-300">
                {upcomingEvents.map((evt) => (
                  <li
                    key={evt.id}
                    className="p-2 rounded-xl bg-slate-800/70 border border-slate-700/60 hover:border-blue-400/50 transition group"
                  >
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="font-black text-sky-300">
                        {formatDateDouala(evt.startDate)}
                      </span>
                      <span className="text-[9px] uppercase font-bold px-1.5 py-0.2 rounded-full bg-slate-700 text-slate-300">
                        {evt.type}
                      </span>
                    </div>
                    <p className="font-bold text-white text-xs mt-0.5 group-hover:text-sky-200 transition">
                      {evt.title}
                    </p>
                    {evt.location && (
                      <p className="text-[10px] text-slate-400 flex items-center space-x-1 mt-0.5">
                        <MapPin className="w-2.5 h-2.5 text-slate-500" />
                        <span className="truncate">{evt.location}</span>
                      </p>
                    )}
                  </li>
                ))}
              </ul>
            ) : (
              <div className="p-3 rounded-xl bg-slate-800/50 border border-slate-700 text-slate-400 text-xs">
                Tous les rassemblements se tiennent selon les cultes hebdomadaires ci-contre.
              </div>
            )}

            <a
              href="#events"
              onClick={(e) => {
                e.preventDefault();
                setEventsDisplayMode('calendar');
                const el = document.getElementById('events');
                if (el) el.scrollIntoView({ behavior: 'smooth' });
              }}
              className="text-[11px] text-sky-400 hover:text-sky-300 font-bold transition flex items-center space-x-1 pt-1 cursor-pointer"
            >
              <span>Consulter le calendrier interactif</span>
              <ArrowRight className="w-3 h-3" />
            </a>
          </div>

          {/* Colonne 4 : Coordonnées Officielles & Contact */}
          <div className="space-y-3">
            <span className="font-bold uppercase tracking-wider text-[#C99B2E] text-[11px] block">
              Contact & Permanence
            </span>
            <ul className="space-y-2 text-slate-300">
              <li>
                <a
                  href={`tel:${settings.phone}`}
                  className="flex items-center space-x-2 text-slate-300 hover:text-white transition group"
                >
                  <div className="w-7 h-7 rounded-lg bg-slate-800 group-hover:bg-[#C99B2E] text-[#C99B2E] group-hover:text-[#0B2D54] flex items-center justify-center transition border border-slate-700 shrink-0">
                    <Phone className="w-3.5 h-3.5" />
                  </div>
                  <div className="truncate">
                    <span className="text-[10px] text-slate-500 block font-bold uppercase">Téléphone</span>
                    <span className="font-bold">{settings.phone}</span>
                  </div>
                </a>
              </li>
              <li>
                <a
                  href={`mailto:${settings.email}`}
                  className="flex items-center space-x-2 text-slate-300 hover:text-white transition group"
                >
                  <div className="w-7 h-7 rounded-lg bg-slate-800 group-hover:bg-[#C99B2E] text-[#C99B2E] group-hover:text-[#0B2D54] flex items-center justify-center transition border border-slate-700 shrink-0">
                    <Mail className="w-3.5 h-3.5" />
                  </div>
                  <div className="truncate">
                    <span className="text-[10px] text-slate-500 block font-bold uppercase">Email Officiel</span>
                    <span className="font-bold truncate max-w-[170px] block">{settings.email}</span>
                  </div>
                </a>
              </li>
              <li className="flex items-center space-x-2 pt-0.5">
                <div className="w-7 h-7 rounded-lg bg-slate-800 text-[#C99B2E] flex items-center justify-center shrink-0 border border-slate-700">
                  <Clock className="w-3.5 h-3.5" />
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 block font-bold uppercase">Secrétariat Paroissial</span>
                  <span className="text-slate-300 text-[11px]">Mar - Sam : 08h30 - 17h00</span>
                </div>
              </li>
            </ul>

            <div className="pt-2">
              <a
                href={
                  settings.socials.whatsapp
                    ? settings.socials.whatsapp.startsWith('http')
                      ? settings.socials.whatsapp
                      : `https://wa.me/${settings.socials.whatsapp.replace(/\D/g, '')}`
                    : `https://wa.me/${settings.phone.replace(/\D/g, '')}`
                }
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-2 px-3 rounded-xl bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-xs flex items-center justify-center space-x-2 transition shadow-sm"
              >
                <span>Contacter le Pasteur par WhatsApp</span>
              </a>
            </div>
          </div>
        </div>

        {/* Barre Inférieure Légale */}
        <div className="max-w-7xl mx-auto pt-6 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between text-[11px] text-slate-500 gap-3">
          <div>
            © 2026 {settings.churchName}. Tous droits réservés.
          </div>
          <div className="flex items-center space-x-4">
            <span>Fuseau : {settings.timezone}</span>
            <span>•</span>
            <span>Devise : {settings.currency}</span>
            <span>•</span>
            <span className="text-[#C99B2E]">EMF SMART Sangmelima</span>
          </div>
        </div>
      </footer>

      {/* Admin Manage Carousel Modal */}
      <ManageCarouselModal
        isOpen={isManageCarouselOpen}
        onClose={() => setIsManageCarouselOpen(false)}
        slides={carouselSlides}
        onSlidesUpdated={loadData}
        initialCreateMode={carouselModalCreateMode}
      />

      {/* Admin Manage Weekly Programs Modal */}
      <ManageWeeklyProgramsModal
        isOpen={isManageProgramsOpen}
        onClose={() => setIsManageProgramsOpen(false)}
        programs={weeklyPrograms}
        onProgramsUpdated={loadData}
        initialCreateMode={programsModalCreateMode}
      />

      {/* Member Join Community Modal */}
      <JoinCommunityModal
        isOpen={isJoinCommunityOpen}
        onClose={() => setIsJoinCommunityOpen(false)}
        onSuccess={loadData}
      />

      {/* Admin Footer & Church Synchronizer Modal */}
      <FooterChurchEditorModal
        isOpen={isFooterEditorOpen}
        onClose={() => setIsFooterEditorOpen(false)}
        weeklyPrograms={weeklyPrograms}
        events={events}
        onOpenProgramsManager={() => {
          setProgramsModalCreateMode(false);
          setIsManageProgramsOpen(true);
        }}
        onNavigateToEvents={onNavigateToPage ? () => onNavigateToPage('events') : undefined}
        onRefreshData={loadData}
      />
    </div>
  );
};
