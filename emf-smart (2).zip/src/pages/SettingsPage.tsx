import React, { useState } from 'react';
import { Settings as SettingsIcon, Save, Palette, Church, Globe, CheckCircle, Users } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { SystemSettings } from '../types';
import { AdminLeadershipAndTreasurySettings } from '../components/admin/AdminLeadershipAndTreasurySettings';

export const SettingsPage: React.FC = () => {
  const { settings, updateSettings, hasRole } = useAuth();
  const [formData, setFormData] = useState<SystemSettings>(JSON.parse(JSON.stringify(settings)));
  const [notification, setNotification] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setNotification(msg);
    setTimeout(() => setNotification(null), 3500);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    await updateSettings(formData);
    showToast('Paramètres généraux et identité visuelle enregistrés avec succès !');
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {notification && (
        <div className="fixed bottom-4 right-4 z-50 bg-[#0B2D54] text-white px-5 py-3 rounded-xl shadow-2xl border border-[#C99B2E] flex items-center space-x-2 animate-in slide-in-from-bottom">
          <CheckCircle className="w-5 h-5 text-[#C99B2E]" />
          <span className="text-xs font-bold">{notification}</span>
        </div>
      )}

      {/* Header Banner */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2 text-xs font-bold text-[#C99B2E] uppercase tracking-wider mb-1">
            <SettingsIcon className="w-4 h-4 text-[#123B6D]" />
            <span>Configuration Système • Sangmelima</span>
          </div>
          <h1 className="text-2xl font-black text-[#0B2D54]">Paramètres de l’Église</h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Identité officielle, thème de couleurs, fuseau horaire et modules activables
          </p>
        </div>

        {hasRole('ADMIN') && (
          <button
            onClick={handleSave}
            className="px-4 py-2 bg-[#123B6D] hover:bg-[#0B2D54] text-white text-xs font-bold rounded-xl transition shadow flex items-center space-x-1.5"
          >
            <Save className="w-4 h-4 text-[#C99B2E]" />
            <span>Enregistrer les Paramètres</span>
          </button>
        )}
      </div>

      {/* Section Officiers Clés (Pasteur, Secrétaire, Trésorier) & Trésorerie */}
      {hasRole('ADMIN') && (
        <div id="direction-tresorerie-section">
          <AdminLeadershipAndTreasurySettings initialTab="officers" allowTreasury={true} />
        </div>
      )}

      {/* Section Paramètres Généraux & Thème Visuel */}
      <div className="pt-2">
        <h2 className="text-sm font-black text-[#0B2D54] uppercase tracking-wider mb-3">
          Identité Institutionnelle & Configuration Globale
        </h2>
      </div>

      <form onSubmit={handleSave} className="grid grid-cols-1 lg:grid-cols-2 gap-6 text-xs">
        {/* Box 1: Identité Institutionnelle */}
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center space-x-2 pb-3 border-b border-slate-100">
            <Church className="w-4 h-4 text-[#123B6D]" />
            <h3 className="font-bold text-sm text-[#0B2D54]">Identité de l’Église</h3>
          </div>

          <div>
            <label className="block font-bold text-slate-700 mb-1">Nom Officiel de l’Église *</label>
            <input
              type="text"
              required
              value={formData.churchName}
              onChange={(e) => setFormData({ ...formData, churchName: e.target.value })}
              className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-[#123B6D]"
            />
          </div>

          <div>
            <label className="block font-bold text-slate-700 mb-1">Slogan / Devise Pastorale</label>
            <textarea
              rows={2}
              value={formData.slogan}
              onChange={(e) => setFormData({ ...formData, slogan: e.target.value })}
              className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-[#123B6D]"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-700 mb-1">Ville</label>
              <input
                type="text"
                value={formData.city}
                onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-xl"
              />
            </div>
            <div>
              <label className="block font-bold text-slate-700 mb-1">Pays</label>
              <input
                type="text"
                value={formData.country}
                onChange={(e) => setFormData({ ...formData, country: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-xl"
              />
            </div>
          </div>

          <div>
            <label className="block font-bold text-slate-700 mb-1">Adresse Complète</label>
            <input
              type="text"
              value={formData.address}
              onChange={(e) => setFormData({ ...formData, address: e.target.value })}
              className="w-full px-3 py-2 border border-slate-300 rounded-xl"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-700 mb-1">Téléphone Principal</label>
              <input
                type="text"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-xl"
              />
            </div>
            <div>
              <label className="block font-bold text-slate-700 mb-1">Email Principal</label>
              <input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-xl"
              />
            </div>
          </div>
        </div>

        {/* Box: Liens Sociaux & Canaux Numériques */}
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center space-x-2 pb-3 border-b border-slate-100">
            <Globe className="w-4 h-4 text-[#123B6D]" />
            <h3 className="font-bold text-sm text-[#0B2D54]">Réseaux Sociaux & Canaux Numériques</h3>
          </div>

          <div className="space-y-3">
            <div>
              <label className="block font-bold text-slate-700 mb-1">Page Facebook Officielle</label>
              <input
                type="url"
                value={formData.socials?.facebook || ''}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    socials: { ...formData.socials, facebook: e.target.value },
                  })
                }
                placeholder="https://facebook.com/emfsangmelima"
                className="w-full px-3 py-2 border border-slate-300 rounded-xl"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Chaîne YouTube (Cultes & Chants)</label>
              <input
                type="url"
                value={formData.socials?.youtube || ''}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    socials: { ...formData.socials, youtube: e.target.value },
                  })
                }
                placeholder="https://youtube.com/@emfsangmelima"
                className="w-full px-3 py-2 border border-slate-300 rounded-xl"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Ligne WhatsApp / Canal</label>
                <input
                  type="text"
                  value={formData.socials?.whatsapp || ''}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      socials: { ...formData.socials, whatsapp: e.target.value },
                    })
                  }
                  placeholder="+237699001122 ou lien wa.me"
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Compte Instagram</label>
                <input
                  type="url"
                  value={formData.socials?.instagram || ''}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      socials: { ...formData.socials, instagram: e.target.value },
                    })
                  }
                  placeholder="https://instagram.com/emfsangmelima"
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Canal Telegram</label>
                <input
                  type="url"
                  value={formData.socials?.telegram || ''}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      socials: { ...formData.socials, telegram: e.target.value },
                    })
                  }
                  placeholder="https://t.me/emfsangmelima"
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Compte TikTok (Jeunesse)</label>
                <input
                  type="url"
                  value={formData.socials?.tiktok || ''}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      socials: { ...formData.socials, tiktok: e.target.value },
                    })
                  }
                  placeholder="https://tiktok.com/@emfsangmelima"
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Box 2: Thème & Couleurs Institutionnelles */}
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center space-x-2 pb-3 border-b border-slate-100">
            <Palette className="w-4 h-4 text-[#123B6D]" />
            <h3 className="font-bold text-sm text-[#0B2D54]">Thème Visuel & Charte Graphique</h3>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block font-bold text-slate-700 mb-1">Bleu Principal</label>
              <div className="flex items-center space-x-2">
                <input
                  type="color"
                  value={formData.theme.primaryColor}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      theme: { ...formData.theme, primaryColor: e.target.value },
                    })
                  }
                  className="w-8 h-8 rounded border cursor-pointer"
                />
                <span className="font-mono text-xs">{formData.theme.primaryColor}</span>
              </div>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Bleu Foncé</label>
              <div className="flex items-center space-x-2">
                <input
                  type="color"
                  value={formData.theme.secondaryColor}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      theme: { ...formData.theme, secondaryColor: e.target.value },
                    })
                  }
                  className="w-8 h-8 rounded border cursor-pointer"
                />
                <span className="font-mono text-xs">{formData.theme.secondaryColor}</span>
              </div>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Or / Doré</label>
              <div className="flex items-center space-x-2">
                <input
                  type="color"
                  value={formData.theme.goldColor}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      theme: { ...formData.theme, goldColor: e.target.value },
                    })
                  }
                  className="w-8 h-8 rounded border cursor-pointer"
                />
                <span className="font-mono text-xs">{formData.theme.goldColor}</span>
              </div>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Arrière-plan</label>
              <div className="flex items-center space-x-2">
                <input
                  type="color"
                  value={formData.theme.backgroundColor}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      theme: { ...formData.theme, backgroundColor: e.target.value },
                    })
                  }
                  className="w-8 h-8 rounded border cursor-pointer"
                />
                <span className="font-mono text-xs">{formData.theme.backgroundColor}</span>
              </div>
            </div>
          </div>

          <div className="pt-2 border-t border-slate-100">
            <label className="block font-bold text-slate-700 mb-1">Logo Officiel Actuel</label>
            <div className="flex items-center space-x-3 mb-2">
              <div className="w-16 h-16 rounded-full overflow-hidden border-2 border-[#C99B2E] bg-white flex items-center justify-center p-1 shadow-sm">
                <img
                  src={formData.logoUrl || '/logo.png'}
                  alt="Logo preview"
                  className="w-full h-full object-contain"
                />
              </div>
              <div className="text-xs text-slate-500">
                <p className="font-bold text-slate-800">Emblème Officiel EMF Sangmelima</p>
                <p className="text-[11px] text-slate-400">Colombe de la paix, globe et Sainte Bible</p>
              </div>
            </div>
            <input
              type="text"
              value={formData.logoUrl || ''}
              onChange={(e) => setFormData({ ...formData, logoUrl: e.target.value })}
              placeholder="/logo.png"
              className="w-full px-3 py-2 border border-slate-300 rounded-xl font-mono text-[11px]"
            />
            <p className="text-[11px] text-slate-400 mt-1">
              Logo officiel appliqué sur l'en-tête, les reçus financiers, les cartes membres et les rapports.
            </p>
          </div>

          {/* Regional Settings */}
          <div className="pt-3 border-t border-slate-100 grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-700 mb-1">Fuseau Horaire</label>
              <input
                type="text"
                disabled
                value={formData.timezone}
                className="w-full px-3 py-2 border border-slate-300 rounded-xl bg-slate-50 font-mono text-slate-600"
              />
            </div>
            <div>
              <label className="block font-bold text-slate-700 mb-1">Devise Officielle</label>
              <input
                type="text"
                disabled
                value={`${formData.currency} (Franc CFA)`}
                className="w-full px-3 py-2 border border-slate-300 rounded-xl bg-slate-50 font-mono text-slate-600"
              />
            </div>
          </div>
        </div>

        {/* Box 3: Modules Activables / Désactivables */}
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-4 lg:col-span-2">
          <h3 className="font-bold text-sm text-[#0B2D54]">Activation des Modules Optionnels</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <label className="p-3 border border-slate-200 rounded-xl flex items-center space-x-3 cursor-pointer hover:bg-slate-50">
              <input
                type="checkbox"
                checked={formData.modules.parakletosEnabled}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    modules: { ...formData.modules, parakletosEnabled: e.target.checked },
                  })
                }
                className="rounded text-[#123B6D]"
              />
              <div>
                <span className="font-bold text-slate-900 block">Institut Biblique Parakletos</span>
                <span className="text-[11px] text-slate-500">Gestion académique et cours</span>
              </div>
            </label>

            <label className="p-3 border border-slate-200 rounded-xl flex items-center space-x-3 cursor-pointer hover:bg-slate-50">
              <input
                type="checkbox"
                checked={formData.modules.forumEnabled}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    modules: { ...formData.modules, forumEnabled: e.target.checked },
                  })
                }
                className="rounded text-[#123B6D]"
              />
              <div>
                <span className="font-bold text-slate-900 block">Forum Chrétien</span>
                <span className="text-[11px] text-slate-500">Discussions et questions</span>
              </div>
            </label>

            <label className="p-3 border border-slate-200 rounded-xl flex items-center space-x-3 cursor-pointer hover:bg-slate-50">
              <input
                type="checkbox"
                checked={formData.modules.testimonialsEnabled}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    modules: { ...formData.modules, testimonialsEnabled: e.target.checked },
                  })
                }
                className="rounded text-[#123B6D]"
              />
              <div>
                <span className="font-bold text-slate-900 block">Témoignages & Miracles</span>
                <span className="text-[11px] text-slate-500">Soumission et modération</span>
              </div>
            </label>

            <label className="p-3 border border-slate-200 rounded-xl flex items-center space-x-3 cursor-pointer hover:bg-slate-50">
              <input
                type="checkbox"
                checked={formData.modules.prayerRequestsEnabled}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    modules: { ...formData.modules, prayerRequestsEnabled: e.target.checked },
                  })
                }
                className="rounded text-[#123B6D]"
              />
              <div>
                <span className="font-bold text-slate-900 block">Requêtes de Prière</span>
                <span className="text-[11px] text-slate-500">Sujets anonymes & intercession</span>
              </div>
            </label>
          </div>
        </div>
      </form>
    </div>
  );
};
