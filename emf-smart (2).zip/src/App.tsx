import React, { useState } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { Header } from './components/layout/Header';
import { Sidebar } from './components/layout/Sidebar';
import { MobileNav } from './components/layout/MobileNav';
import { ReceiptModal } from './components/common/ReceiptModal';
import { MemberBadgeModal } from './components/common/MemberBadgeModal';

// Pages
import { DashboardPage } from './pages/DashboardPage';
import { PublicHomePage } from './pages/PublicHomePage';
import { MembersPage } from './pages/MembersPage';
import { FamiliesPage } from './pages/FamiliesPage';
import { AttendancePage } from './pages/AttendancePage';
import { FinancesPage } from './pages/FinancesPage';
import { EventsPage } from './pages/EventsPage';
import { MinistriesPage } from './pages/MinistriesPage';
import { CommunicationPage } from './pages/CommunicationPage';
import { TestimonialsPage } from './pages/TestimonialsPage';
import { ForumPage } from './pages/ForumPage';
import { VersesPage } from './pages/VersesPage';
import { MediaPage } from './pages/MediaPage';
import { MediaGalleryPage } from './pages/MediaGalleryPage';
import { ParakletosPage } from './pages/ParakletosPage';
import { ReportsPage } from './pages/ReportsPage';
import { CMSHomepagePage } from './pages/CMSHomepagePage';
import { UsersPage } from './pages/UsersPage';
import { SettingsPage } from './pages/SettingsPage';
import { AuditPage } from './pages/AuditPage';
import { BackupsPage } from './pages/BackupsPage';
import { PrayerRequestsPage } from './pages/PrayerRequestsPage';
import { AssociatedChurchesPage } from './pages/AssociatedChurchesPage';
import { HomeCellsPage } from './pages/HomeCellsPage';
import { WebPublishPage } from './pages/WebPublishPage';
import { WebPublishModal } from './components/publish/WebPublishModal';
import { ResourcesPage } from './pages/ResourcesPage';

import { Transaction, Member } from './types';

const MainApp: React.FC = () => {
  const { currentUser, isLoading } = useAuth();
  const isPastorOrAdmin = currentUser?.role === 'ADMIN' || currentUser?.role === 'PASTEUR';
  const [currentPage, setCurrentPage] = useState<string>(() => {
    if (typeof window !== 'undefined' && window.location.hash) {
      const hash = window.location.hash.replace('#', '').trim();
      if (hash) return hash;
    }
    // Le portail de l'application est la première page d'affichage lorsque l'utilisateur accède à l'application
    return 'public-home';
  });
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeReceipt, setActiveReceipt] = useState<Transaction | null>(null);
  const [activeBadgeMember, setActiveBadgeMember] = useState<Member | null>(null);
  const [isWebPublishOpen, setIsWebPublishOpen] = useState(false);

  // Sync hash changes
  React.useEffect(() => {
    const handleHash = () => {
      if (typeof window !== 'undefined' && window.location.hash) {
        const hash = window.location.hash.replace('#', '').trim();
        if (hash) setCurrentPage(hash);
      }
    };
    window.addEventListener('hashchange', handleHash);
    return () => window.removeEventListener('hashchange', handleHash);
  }, []);

  // If user role switches or changes and user is not admin or pasteur, ensure they cannot access dashboard, cms, or web-publish
  React.useEffect(() => {
    if (!isLoading && !isPastorOrAdmin) {
      if (['dashboard', 'cms-homepage', 'web-publish'].includes(currentPage)) {
        setCurrentPage('prayer-requests');
      }
    }
  }, [currentUser?.role, currentPage, isLoading, isPastorOrAdmin]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#F4F7FB] flex items-center justify-center">
        <div className="text-center space-y-3">
          <div className="w-12 h-12 border-4 border-[#123B6D] border-t-[#C99B2E] rounded-full animate-spin mx-auto" />
          <h2 className="text-sm font-bold text-[#0B2D54]">EMF SMART — Sangmelima</h2>
          <p className="text-xs text-slate-400">Chargement de la plateforme...</p>
        </div>
      </div>
    );
  }

  // If viewing the public homepage, render it in full-bleed mode
  if (currentPage === 'public-home') {
    return (
      <div className="min-h-screen bg-[#F4F7FB]">
        <PublicHomePage
          onGoToDashboard={() => setCurrentPage(isPastorOrAdmin ? 'dashboard' : 'prayer-requests')}
          onGoToCMS={() => {
            if (isPastorOrAdmin) setCurrentPage('cms-homepage');
          }}
          onGoToPrayers={() => setCurrentPage('prayer-requests')}
          onNavigateToPage={(page) => setCurrentPage(page)}
          onOpenPublish={isPastorOrAdmin ? () => setIsWebPublishOpen(true) : undefined}
        />
        {isPastorOrAdmin && (
          <WebPublishModal
            isOpen={isWebPublishOpen}
            onClose={() => setIsWebPublishOpen(false)}
            onNavigateToPublicHome={() => setCurrentPage('public-home')}
            onNavigateToPage={(page) => setCurrentPage(page)}
          />
        )}
      </div>
    );
  }

  const renderActivePage = () => {
    switch (currentPage) {
      case 'dashboard':
        if (!isPastorOrAdmin) {
          return <PrayerRequestsPage onNavigate={(page) => setCurrentPage(page)} />;
        }
        return (
          <DashboardPage
            onNavigate={(page) => setCurrentPage(page)}
            onOpenReceipt={(tx) => setActiveReceipt(tx)}
          />
        );
      case 'prayer-requests':
        return <PrayerRequestsPage onNavigate={(page) => setCurrentPage(page)} />;
      case 'members':
        return <MembersPage onOpenBadge={(m) => setActiveBadgeMember(m)} />;
      case 'families':
        return <FamiliesPage />;
      case 'attendance':
        return <AttendancePage />;
      case 'finances':
        return <FinancesPage onOpenReceipt={(tx) => setActiveReceipt(tx)} />;
      case 'events':
        return <EventsPage />;
      case 'ministries':
        return <MinistriesPage />;
      case 'home-cells':
        return <HomeCellsPage />;
      case 'associated-churches':
        return <AssociatedChurchesPage />;
      case 'communication':
        return <CommunicationPage />;
      case 'testimonials':
        return <TestimonialsPage />;
      case 'forum':
        return <ForumPage />;
      case 'verses':
        return <VersesPage />;
      case 'resources':
        return <ResourcesPage onNavigate={(page) => setCurrentPage(page)} />;
      case 'media':
      case 'media-gallery':
        return <MediaGalleryPage />;
      case 'parakletos':
        return <ParakletosPage />;
      case 'reports':
        return <ReportsPage />;
      case 'cms-homepage':
        if (!isPastorOrAdmin) {
          return <PrayerRequestsPage onNavigate={(page) => setCurrentPage(page)} />;
        }
        return (
          <CMSHomepagePage
            onPreviewPublic={() => setCurrentPage('public-home')}
            onOpenPublish={() => setIsWebPublishOpen(true)}
          />
        );
      case 'web-publish':
        if (!isPastorOrAdmin) {
          return <PrayerRequestsPage onNavigate={(page) => setCurrentPage(page)} />;
        }
        return (
          <WebPublishPage
            onNavigateToPublicHome={() => setCurrentPage('public-home')}
            onNavigateToPage={(page) => setCurrentPage(page)}
          />
        );
      case 'users':
        return <UsersPage />;
      case 'settings':
        return <SettingsPage />;
      case 'audit':
        return <AuditPage />;
      case 'backups':
        return <BackupsPage />;
      default:
        if (isPastorOrAdmin) {
          return (
            <DashboardPage
              onNavigate={(page) => setCurrentPage(page)}
              onOpenReceipt={(tx) => setActiveReceipt(tx)}
            />
          );
        }
        return <PrayerRequestsPage onNavigate={(page) => setCurrentPage(page)} />;
    }
  };

  return (
    <div className="min-h-screen bg-[#F4F7FB] flex flex-col font-sans selection:bg-[#C99B2E] selection:text-[#0B2D54]">
      {/* Top Header */}
      <Header
        onToggleMobileMenu={() => setMobileMenuOpen(true)}
        onNavigate={(page) => setCurrentPage(page)}
        currentPage={currentPage}
      />

      <div className="flex-1 flex">
        {/* Desktop Sidebar */}
        <div className="hidden md:block">
          <Sidebar
            currentPage={currentPage}
            onNavigate={(page) => setCurrentPage(page)}
          />
        </div>

        {/* Mobile Navigation Drawer & Bottom Bar */}
        <MobileNav
          isOpen={mobileMenuOpen}
          onClose={() => setMobileMenuOpen(false)}
          currentPage={currentPage}
          onNavigate={(page) => setCurrentPage(page)}
        />

        {/* Main Content Workspace */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto w-full pb-20 md:pb-8">
          {renderActivePage()}
        </main>
      </div>

      {/* Official Modals */}
      <ReceiptModal
        transaction={activeReceipt}
        onClose={() => setActiveReceipt(null)}
      />

      <MemberBadgeModal
        member={activeBadgeMember}
        onClose={() => setActiveBadgeMember(null)}
      />

      {isPastorOrAdmin && (
        <WebPublishModal
          isOpen={isWebPublishOpen}
          onClose={() => setIsWebPublishOpen(false)}
          onNavigateToPublicHome={() => setCurrentPage('public-home')}
          onNavigateToPage={(page) => setCurrentPage(page)}
        />
      )}
    </div>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <MainApp />
    </AuthProvider>
  );
}
