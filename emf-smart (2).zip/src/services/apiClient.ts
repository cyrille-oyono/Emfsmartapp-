import { Storage } from '../server/storage';
import {
  User,
  Member,
  Family,
  Ministry,
  AttendanceSession,
  AttendanceRecord,
  Transaction,
  Event,
  Announcement,
  Testimonial,
  ForumTopic,
  ForumPost,
  DailyBibleVerse,
  MediaItem,
  SystemSettings,
  HomepageSection,
  HomepageCMSState,
  AuditLog,
  BackupRecord,
  PrayerRequest,
  Role,
  Department,
  AssociatedChurch,
  HomeCell,
  MinistryAdhesionRequest,
  HomepageCarouselSlide,
  LatestServiceMedia,
  ServiceMediaPhoto,
  ServiceMediaVideo,
  AppNotification,
  NotificationCategory,
  TreasurySettings,
  ChurchResource,
  WeeklyProgram,
} from '../types';
import { churchSyncService } from './churchSyncService';

export const apiClient = {
  // Auth
  async login(email: string, password: string): Promise<{ success: boolean; user?: User; error?: string }> {
    const user = Storage.authenticateUser(email, password);
    if (!user) {
      return { success: false, error: 'Identifiants invalides. Veuillez vérifier votre adresse email et mot de passe.' };
    }
    return { success: true, user };
  },

  async getCurrentSettings(): Promise<SystemSettings> {
    return Storage.getSettings();
  },

  async updateSettings(settings: Partial<SystemSettings>, user?: User): Promise<SystemSettings> {
    const res = Storage.updateSettings(settings, user);
    churchSyncService.broadcastSettingsUpdated(res);
    return res;
  },

  // Members
  async getMembers(): Promise<Member[]> {
    return Storage.getMembers();
  },

  async createMember(data: any, user?: User): Promise<Member> {
    return Storage.createMember(data, user);
  },

  async submitCommunityAdhesion(data: any): Promise<{ success: boolean; member: Member; message: string }> {
    return Storage.submitCommunityAdhesion(data);
  },

  async updateMember(id: string, data: Partial<Member>, user?: User): Promise<Member | null> {
    return Storage.updateMember(id, data, user);
  },

  async deleteMember(id: string, user?: User): Promise<boolean> {
    return Storage.deleteMember(id, user);
  },

  // Families
  async getFamilies(): Promise<Family[]> {
    return Storage.getFamilies();
  },

  async createFamily(data: any, user?: User): Promise<Family> {
    return Storage.createFamily(data, user);
  },

  async updateFamily(id: string, data: Partial<Family>, user?: User): Promise<Family | null> {
    return Storage.updateFamily(id, data, user);
  },

  async deleteFamily(id: string, user?: User): Promise<boolean> {
    return Storage.deleteFamily(id, user);
  },

  // Ministries
  async getMinistries(): Promise<Ministry[]> {
    return Storage.getMinistries();
  },

  async createMinistry(data: any, user?: User): Promise<Ministry> {
    return Storage.createMinistry(data, user);
  },

  async updateMinistry(id: string, data: Partial<Ministry>, user?: User): Promise<Ministry | null> {
    return Storage.updateMinistry(id, data, user);
  },

  async deleteMinistry(id: string, user?: User): Promise<boolean> {
    return Storage.deleteMinistry(id, user);
  },

  // Attendance
  async getAttendanceSessions(): Promise<AttendanceSession[]> {
    return Storage.getAttendanceSessions();
  },

  async createAttendanceSession(data: any, user?: User): Promise<AttendanceSession> {
    return Storage.createAttendanceSession(data, user);
  },

  async getAttendanceRecords(sessionId: string): Promise<AttendanceRecord[]> {
    return Storage.getAttendanceRecords(sessionId);
  },

  async getAllAttendanceRecords(): Promise<AttendanceRecord[]> {
    return Storage.getAllAttendanceRecords();
  },

  async saveAttendanceRecords(sessionId: string, records: AttendanceRecord[], user?: User): Promise<void> {
    return Storage.saveAttendanceRecords(sessionId, records, user);
  },

  // Finances
  async getTransactions(): Promise<Transaction[]> {
    return Storage.getTransactions();
  },

  async getTransactionCategories() {
    return Storage.getTransactionCategories();
  },

  async createTransaction(data: any, user?: User): Promise<Transaction> {
    return Storage.createTransaction(data, user);
  },

  async deleteTransaction(id: string, user?: User): Promise<boolean> {
    return Storage.deleteTransaction(id, user);
  },

  async getFinancialsSummary() {
    return Storage.getFinancialsSummary();
  },

  // Events
  async getEvents(): Promise<Event[]> {
    return Storage.getEvents();
  },

  async createEvent(data: any, user?: User): Promise<Event> {
    const res = Storage.createEvent(data, user);
    churchSyncService.broadcastAgendaUpdated({ message: `Événement créé : ${res.title}` });
    return res;
  },

  async updateEvent(id: string, data: Partial<Event>, user?: User): Promise<Event | null> {
    const res = Storage.updateEvent(id, data, user);
    churchSyncService.broadcastAgendaUpdated({ message: 'Événement mis à jour' });
    return res;
  },

  async deleteEvent(id: string, user?: User): Promise<boolean> {
    const res = Storage.deleteEvent(id, user);
    churchSyncService.broadcastAgendaUpdated({ message: 'Événement supprimé' });
    return res;
  },

  // Communications
  async getAnnouncements(): Promise<Announcement[]> {
    return Storage.getAnnouncements();
  },

  async createAnnouncement(data: any, user?: User): Promise<Announcement> {
    return Storage.createAnnouncement(data, user);
  },

  async deleteAnnouncement(id: string, user?: User): Promise<boolean> {
    return Storage.deleteAnnouncement(id, user);
  },

  // Testimonials
  async getTestimonials(onlyValidated = false): Promise<Testimonial[]> {
    return Storage.getTestimonials(onlyValidated);
  },

  async submitTestimonial(data: any, user?: User): Promise<Testimonial> {
    return Storage.submitTestimonial(data, user);
  },

  async moderateTestimonial(
    id: string,
    status: 'VALIDÉ' | 'REJETÉ' | 'MASQUÉ',
    reason?: string,
    user?: User
  ): Promise<Testimonial | null> {
    return Storage.moderateTestimonial(id, status, reason, user);
  },

  // Forum
  async getForumCategories() {
    return Storage.getForumCategories();
  },

  async getForumTopics(categoryId?: string): Promise<ForumTopic[]> {
    return Storage.getForumTopics(categoryId);
  },

  async getForumPosts(topicId: string): Promise<ForumPost[]> {
    return Storage.getForumPosts(topicId);
  },

  async createForumTopic(categoryId: string, title: string, content: string, user: User) {
    return Storage.createForumTopic(categoryId, title, content, user);
  },

  async createForumPost(topicId: string, content: string, user: User) {
    return Storage.createForumPost(topicId, content, user);
  },

  async reportForumPost(postId: string, reason: string, user: User) {
    return Storage.reportForumPost(postId, reason, user);
  },

  async getForumReports() {
    return Storage.getForumReports();
  },

  // Verses
  async getDailyVerses(): Promise<DailyBibleVerse[]> {
    return Storage.getDailyVerses();
  },

  async getTodayVerse(): Promise<DailyBibleVerse | undefined> {
    return Storage.getTodayVerse();
  },

  async createDailyVerse(data: any, user?: User): Promise<DailyBibleVerse> {
    return Storage.createDailyVerse(data, user);
  },

  // Media
  async getMediaItems(): Promise<MediaItem[]> {
    return Storage.getMediaItems();
  },

  async createMediaItem(data: any, user?: User): Promise<MediaItem> {
    return Storage.createMediaItem(data, user);
  },

  async deleteMediaItem(id: string, user?: User): Promise<boolean> {
    return Storage.deleteMediaItem(id, user);
  },

  // Parakletos
  async getParakletosState() {
    return Storage.getParakletosState();
  },

  async updateParakletosInfo(infoUpdates: any, user?: User) {
    return Storage.updateParakletosInfo(infoUpdates, user);
  },

  async createParakletosClass(data: any, user?: User) {
    return Storage.createParakletosClass(data, user);
  },

  async updateParakletosClass(id: string, updates: any, user?: User) {
    return Storage.updateParakletosClass(id, updates, user);
  },

  async deleteParakletosClass(id: string, user?: User) {
    return Storage.deleteParakletosClass(id, user);
  },

  async createParakletosSubject(data: any, user?: User) {
    return Storage.createParakletosSubject(data, user);
  },

  async updateParakletosSubject(id: string, updates: any, user?: User) {
    return Storage.updateParakletosSubject(id, updates, user);
  },

  async deleteParakletosSubject(id: string, user?: User) {
    return Storage.deleteParakletosSubject(id, user);
  },

  async createParakletosTeacher(data: any, user?: User) {
    return Storage.createParakletosTeacher(data, user);
  },

  async updateParakletosTeacher(id: string, updates: any, user?: User) {
    return Storage.updateParakletosTeacher(id, updates, user);
  },

  async deleteParakletosTeacher(id: string, user?: User) {
    return Storage.deleteParakletosTeacher(id, user);
  },

  async createParakletosAdmission(data: any, user?: User) {
    return Storage.createParakletosAdmission(data, user);
  },

  async updateParakletosAdmissionStatus(id: string, status: any, reviewNotes?: string, user?: User) {
    return Storage.updateParakletosAdmissionStatus(id, status, reviewNotes, user);
  },

  async verifyParakletosAccessCode(code: string) {
    return Storage.verifyParakletosAccessCode(code);
  },

  async createParakletosStudent(data: any, user?: User) {
    return Storage.createParakletosStudent(data, user);
  },

  async recordParakletosGrade(data: any, user?: User) {
    return Storage.recordParakletosGrade(data, user);
  },

  // CMS
  async getCMSState(): Promise<HomepageCMSState> {
    return Storage.getCMSState();
  },

  async getPublicHomepageSections(): Promise<HomepageSection[]> {
    return Storage.getPublicHomepageSections();
  },

  async saveDraftSections(sections: HomepageSection[], user?: User): Promise<HomepageCMSState> {
    return Storage.saveDraftSections(sections, user);
  },

  async publishCMS(user: User): Promise<HomepageCMSState> {
    const res = Storage.publishCMS(user);
    churchSyncService.broadcastCmsUpdated();
    return res;
  },

  async restoreCMSRevision(revisionId: string, user: User): Promise<HomepageCMSState | null> {
    const res = Storage.restoreCMSRevision(revisionId, user);
    churchSyncService.broadcastCmsUpdated();
    return res;
  },

  async quickUpdateHomepage(updates: any, user?: User): Promise<HomepageCMSState> {
    const res = Storage.quickUpdateHomepage(updates, user);
    churchSyncService.broadcastCmsUpdated();
    churchSyncService.broadcastSettingsUpdated(Storage.getSettings());
    return res;
  },

  // Users
  async getUsers(): Promise<User[]> {
    return Storage.getUsers();
  },

  async getUsersWithCredentials(): Promise<(User & { currentPassword?: string })[]> {
    return Storage.getUsersWithCredentials();
  },

  async updateUserPassword(
    userId: string,
    newPassword: string,
    newEmail?: string,
    user?: User
  ): Promise<{ success: boolean; user?: User; error?: string }> {
    return Storage.updateUserPassword(userId, newPassword, newEmail, user);
  },

  async createUser(data: Partial<User>, user?: User): Promise<User> {
    return Storage.createUser(data, user);
  },

  async updateUser(id: string, data: Partial<User>, user?: User): Promise<User | null> {
    return Storage.updateUser(id, data, user);
  },

  // Audits
  async getAuditLogs(): Promise<AuditLog[]> {
    return Storage.getAuditLogs();
  },

  // Backups
  async getBackups(): Promise<BackupRecord[]> {
    return Storage.getBackups();
  },

  async createBackup(type: 'MANUELLE' | 'AUTOMATIQUE', user?: User): Promise<BackupRecord> {
    return Storage.createBackup(type, user);
  },

  async downloadBackupJson(): Promise<string> {
    return JSON.stringify(Storage.getSnapshot(), null, 2);
  },

  // Prayer Requests
  async getPrayerRequests(includeConfidential = false, userRole?: Role): Promise<PrayerRequest[]> {
    return Storage.getPrayerRequests(includeConfidential, userRole);
  },

  async createPrayerRequest(
    data: {
      title: string;
      description: string;
      category: PrayerRequest['category'];
      authorName?: string;
      isAnonymous?: boolean;
      phone?: string;
      isConfidentialPastoralOnly?: boolean;
      status?: PrayerRequest['status'];
    },
    user?: User
  ): Promise<PrayerRequest> {
    return Storage.createPrayerRequest(data, user);
  },

  async updatePrayerRequestStatus(
    id: string,
    status: PrayerRequest['status'],
    user?: User
  ): Promise<PrayerRequest | null> {
    return Storage.updatePrayerRequestStatus(id, status, user);
  },

  async incrementPrayerCount(id: string): Promise<PrayerRequest | null> {
    return Storage.incrementPrayerCount(id);
  },

  async addPrayerTestimony(id: string, testimony: string, user?: User): Promise<PrayerRequest | null> {
    return Storage.addPrayerTestimony(id, testimony, user);
  },

  async deletePrayerRequest(id: string, user?: User): Promise<boolean> {
    return Storage.deletePrayerRequest(id, user);
  },

  // Associated Churches
  async getAssociatedChurches(): Promise<AssociatedChurch[]> {
    return Storage.getAssociatedChurches();
  },

  async createAssociatedChurch(
    data: Omit<AssociatedChurch, 'id' | 'createdAt' | 'updatedAt'>,
    user?: User
  ): Promise<AssociatedChurch> {
    return Storage.createAssociatedChurch(data, user);
  },

  async updateAssociatedChurch(
    id: string,
    updates: Partial<AssociatedChurch>,
    user?: User
  ): Promise<AssociatedChurch | null> {
    return Storage.updateAssociatedChurch(id, updates, user);
  },

  async deleteAssociatedChurch(id: string, user?: User): Promise<boolean> {
    return Storage.deleteAssociatedChurch(id, user);
  },

  // Home Cells
  async getHomeCells(): Promise<HomeCell[]> {
    return Storage.getHomeCells();
  },

  async createHomeCell(
    data: Omit<HomeCell, 'id' | 'createdAt' | 'updatedAt'>,
    user?: User
  ): Promise<HomeCell> {
    return Storage.createHomeCell(data, user);
  },

  async updateHomeCell(
    id: string,
    updates: Partial<HomeCell>,
    user?: User
  ): Promise<HomeCell | null> {
    return Storage.updateHomeCell(id, updates, user);
  },

  async deleteHomeCell(id: string, user?: User): Promise<boolean> {
    return Storage.deleteHomeCell(id, user);
  },

  // Departments
  async getDepartments(ministryId?: string): Promise<Department[]> {
    return Storage.getDepartments(ministryId);
  },

  async createDepartment(
    data: Omit<Department, 'id' | 'createdAt'>,
    user?: User
  ): Promise<Department> {
    return Storage.createDepartment(data, user);
  },

  async updateDepartment(
    id: string,
    updates: Partial<Department>,
    user?: User
  ): Promise<Department | null> {
    return Storage.updateDepartment(id, updates, user);
  },

  async deleteDepartment(id: string, user?: User): Promise<boolean> {
    return Storage.deleteDepartment(id, user);
  },

  // Ministry Adhesions
  async getMinistryAdhesions(ministryId?: string): Promise<MinistryAdhesionRequest[]> {
    return Storage.getMinistryAdhesions(ministryId);
  },

  async createMinistryAdhesion(
    data: Omit<MinistryAdhesionRequest, 'id' | 'status' | 'createdAt' | 'updatedAt'>,
    user?: User
  ): Promise<MinistryAdhesionRequest> {
    return Storage.createMinistryAdhesion(data, user);
  },

  async updateMinistryAdhesionStatus(
    id: string,
    status: MinistryAdhesionRequest['status'],
    reviewNotes?: string,
    user?: User
  ): Promise<MinistryAdhesionRequest | null> {
    return Storage.updateMinistryAdhesionStatus(id, status, reviewNotes, user);
  },

  async deleteMinistryAdhesion(id: string, user?: User): Promise<boolean> {
    return Storage.deleteMinistryAdhesion(id, user);
  },

  // Carousel
  async getCarouselSlides(): Promise<HomepageCarouselSlide[]> {
    return Storage.getCarouselSlides();
  },

  async createCarouselSlide(
    data: Omit<HomepageCarouselSlide, 'id'>,
    user?: User
  ): Promise<HomepageCarouselSlide> {
    return Storage.createCarouselSlide(data, user);
  },

  async updateCarouselSlide(
    id: string,
    updates: Partial<HomepageCarouselSlide>,
    user?: User
  ): Promise<HomepageCarouselSlide | null> {
    return Storage.updateCarouselSlide(id, updates, user);
  },

  async deleteCarouselSlide(id: string, user?: User): Promise<boolean> {
    return Storage.deleteCarouselSlide(id, user);
  },

  // Latest Service Media (Photos & Videos)
  async getLatestServiceMedia(): Promise<LatestServiceMedia> {
    return Storage.getLatestServiceMedia();
  },

  async updateLatestServiceMedia(
    updates: Partial<LatestServiceMedia>,
    user?: User
  ): Promise<LatestServiceMedia> {
    return Storage.updateLatestServiceMedia(updates, user);
  },

  async addServicePhoto(
    photo: Omit<ServiceMediaPhoto, 'id' | 'createdAt'>,
    user?: User
  ): Promise<LatestServiceMedia> {
    return Storage.addServicePhoto(photo, user);
  },

  async deleteServicePhoto(photoId: string, user?: User): Promise<LatestServiceMedia> {
    return Storage.deleteServicePhoto(photoId, user);
  },

  async addServiceVideo(
    video: Omit<ServiceMediaVideo, 'id' | 'createdAt'>,
    user?: User
  ): Promise<LatestServiceMedia> {
    return Storage.addServiceVideo(video, user);
  },

  async deleteServiceVideo(videoId: string, user?: User): Promise<LatestServiceMedia> {
    return Storage.deleteServiceVideo(videoId, user);
  },

  // Notifications
  async getNotifications(userId?: string): Promise<(AppNotification & { isRead?: boolean })[]> {
    return Storage.getNotifications(userId);
  },

  async markNotificationAsRead(id: string, userId?: string): Promise<boolean> {
    return Storage.markNotificationAsRead(id, userId);
  },

  async markAllNotificationsAsRead(userId?: string): Promise<boolean> {
    return Storage.markAllNotificationsAsRead(userId);
  },

  async createNotification(data: any, user?: User): Promise<AppNotification> {
    return Storage.createNotification(data, user);
  },

  async deleteNotification(id: string, user?: User): Promise<boolean> {
    return Storage.deleteNotification(id, user);
  },

  // Treasury & Mobile Money / Banking Settings
  async getTreasurySettings(): Promise<TreasurySettings> {
    return Storage.getTreasurySettings();
  },

  async updateTreasurySettings(treasury: TreasurySettings, user?: User): Promise<TreasurySettings> {
    return Storage.updateTreasurySettings(treasury, user);
  },

  // Key Leadership Officers (Pasteur, Secrétaire, Trésorier)
  async getKeyOfficers(): Promise<(User & { currentPassword?: string })[]> {
    return Storage.getKeyOfficers();
  },

  async updateKeyOfficer(
    userId: string,
    data: {
      firstName: string;
      lastName: string;
      phone: string;
      email: string;
      password?: string;
      status?: 'ACTIF' | 'INACTIF';
    },
    user?: User
  ): Promise<{ success: boolean; user?: any; error?: string }> {
    return Storage.updateKeyOfficer(userId, data, user);
  },

  // Church Resources (Enseignements & Prières)
  async getResources(): Promise<ChurchResource[]> {
    return Storage.getResources();
  },

  async createResource(
    data: Omit<ChurchResource, 'id' | 'createdAt' | 'updatedAt' | 'downloadCount'>,
    user?: User
  ): Promise<ChurchResource> {
    return Storage.createResource(data, user);
  },

  async updateResource(
    id: string,
    data: Partial<ChurchResource>,
    user?: User
  ): Promise<ChurchResource | null> {
    return Storage.updateResource(id, data, user);
  },

  async deleteResource(id: string, user?: User): Promise<boolean> {
    return Storage.deleteResource(id, user);
  },

  async incrementResourceDownload(id: string): Promise<ChurchResource | null> {
    return Storage.incrementResourceDownload(id);
  },

  // Weekly Programs (Programmes Hebdomadaires)
  async getWeeklyPrograms(): Promise<WeeklyProgram[]> {
    return Storage.getWeeklyPrograms();
  },

  async createWeeklyProgram(
    data: Omit<WeeklyProgram, 'id' | 'createdAt' | 'updatedAt'>,
    user?: User
  ): Promise<WeeklyProgram> {
    const res = Storage.createWeeklyProgram(data, user);
    churchSyncService.broadcastAgendaUpdated({ message: `Programme hebdomadaire créé : ${res.title}` });
    return res;
  },

  async updateWeeklyProgram(
    id: string,
    updates: Partial<WeeklyProgram>,
    user?: User
  ): Promise<WeeklyProgram | null> {
    const res = Storage.updateWeeklyProgram(id, updates, user);
    churchSyncService.broadcastAgendaUpdated({ message: 'Programme hebdomadaire mis à jour' });
    return res;
  },

  async deleteWeeklyProgram(id: string, user?: User): Promise<boolean> {
    const res = Storage.deleteWeeklyProgram(id, user);
    churchSyncService.broadcastAgendaUpdated({ message: 'Programme hebdomadaire supprimé' });
    return res;
  },

  async reorderWeeklyPrograms(orderedIds: string[], user?: User): Promise<WeeklyProgram[]> {
    const res = Storage.reorderWeeklyPrograms(orderedIds, user);
    churchSyncService.broadcastAgendaUpdated({ message: 'Programmes réorganisés' });
    return res;
  },
};

