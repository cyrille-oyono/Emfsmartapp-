import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, Role, Permission, SystemSettings } from '../types';
import { apiClient } from '../services/apiClient';
import { churchSyncService } from '../services/churchSyncService';

interface AuthContextType {
  currentUser: User | null;
  settings: SystemSettings;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  loginAs: (role: Role) => Promise<void>;
  logout: () => void;
  hasRole: (role: Role | Role[]) => boolean;
  hasPermission: (permission: Permission) => boolean;
  refreshSettings: () => Promise<void>;
  updateSettings: (newSettings: Partial<SystemSettings>) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [settings, setSettings] = useState<SystemSettings>(() => {
    return {
      churchName: 'Église Missionnaire de la Foi de Sangmelima',
      slogan: 'Une église vivante au cœur du Sud, enracinée dans la Parole et tournée vers les nations',
      city: 'Sangmelima',
      country: 'Cameroun',
      address: 'Quartier Akon, Route Principale, Sangmelima',
      phone: '+237 699 00 11 22',
      email: 'contact@emf-sangmelima.org',
      website: 'https://emf-sangmelima.org',
      socials: {
        facebook: 'https://facebook.com/emfsangmelima',
        youtube: 'https://youtube.com/@emfsangmelima',
        whatsapp: '+237699001122',
      },
      timezone: 'Africa/Douala',
      currency: 'FCFA',
      theme: {
        primaryColor: '#123B6D',
        secondaryColor: '#0B2D54',
        goldColor: '#C99B2E',
        backgroundColor: '#F4F7FB',
        whiteColor: '#FFFFFF',
      },
      modules: {
        parakletosEnabled: true,
        forumEnabled: true,
        mediaEnabled: true,
        testimonialsEnabled: true,
        dailyVersesEnabled: true,
        prayerRequestsEnabled: true,
      },
      integrations: {
        emailConfigured: false,
        smsConfigured: false,
        whatsappConfigured: false,
        backupStorageConfigured: true,
      },
    };
  });
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const init = async () => {
      try {
        const loadedSettings = await apiClient.getCurrentSettings();
        setSettings(loadedSettings);

        const savedUser = localStorage.getItem('EMF_AUTH_USER');
        if (savedUser) {
          setCurrentUser(JSON.parse(savedUser));
        } else {
          // Default to ADMIN for immediate discovery if user wants, or leave null
          const users = await apiClient.getUsers();
          const admin = users.find((u) => u.role === 'ADMIN');
          if (admin) {
            setCurrentUser(admin);
            localStorage.setItem('EMF_AUTH_USER', JSON.stringify(admin));
          }
        }
      } catch (err) {
        console.error('Failed to initialize auth and settings:', err);
      } finally {
        setIsLoading(false);
      }
    };
    init();
  }, []);

  const login = async (email: string, password: string) => {
    const res = await apiClient.login(email, password);
    if (res.success && res.user) {
      setCurrentUser(res.user);
      localStorage.setItem('EMF_AUTH_USER', JSON.stringify(res.user));
      return { success: true };
    }
    return { success: false, error: res.error || 'Connexion échouée' };
  };

  const loginAs = async (role: Role) => {
    const users = await apiClient.getUsers();
    const target = users.find((u) => u.role === role);
    if (target) {
      setCurrentUser(target);
      localStorage.setItem('EMF_AUTH_USER', JSON.stringify(target));
    }
  };

  const logout = () => {
    setCurrentUser(null);
    localStorage.removeItem('EMF_AUTH_USER');
  };

  const hasRole = (role: Role | Role[]): boolean => {
    if (!currentUser) return false;
    if (Array.isArray(role)) {
      return role.includes(currentUser.role);
    }
    return currentUser.role === role;
  };

  const hasPermission = (permission: Permission): boolean => {
    if (!currentUser) return false;
    if (currentUser.role === 'ADMIN') return true;
    return currentUser.permissions.includes(permission);
  };

  const refreshSettings = async () => {
    const loaded = await apiClient.getCurrentSettings();
    setSettings(loaded);
  };

  const updateSettings = async (newSettings: Partial<SystemSettings>) => {
    const updated = await apiClient.updateSettings(newSettings, currentUser || undefined);
    setSettings(updated);
    churchSyncService.broadcastSettingsUpdated(updated);
  };

  useEffect(() => {
    const unsubscribe = churchSyncService.subscribe((event) => {
      if (event.type === 'church:settings_updated' && event.payload?.settings) {
        setSettings(event.payload.settings);
      }
    });
    return unsubscribe;
  }, []);

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        settings,
        isLoading,
        login,
        loginAs,
        logout,
        hasRole,
        hasPermission,
        refreshSettings,
        updateSettings,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
